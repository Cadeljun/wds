-- ==============================================================================
-- Migration 004: Comprehensive Delivery Management Schema
-- Tables: Customers, Addresses, Orders (enhanced), Riders (enhanced), 
--         Payments (enhanced), Order_Status_History, and Triggers/Functions
-- ==============================================================================

-- 1. Ensure uuid & postgis extensions exist
create extension if not exists "uuid-ossp";

-- 2. Customers Table (Explicit customer profile table linked to public.users / auth)
create table if not exists public.customers (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete cascade,
  full_name text not null,
  phone text not null,
  email text,
  default_address_id uuid,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- 3. Addresses Table
create table if not exists public.addresses (
  id uuid primary key default uuid_generate_v4(),
  customer_id uuid references public.customers(id) on delete cascade,
  user_id uuid references public.users(id) on delete cascade,
  title text default 'Home', -- e.g. Home, Office, Warehouse
  address text not null,
  city text default 'Accra',
  region text default 'Greater Accra',
  latitude double precision not null,
  longitude double precision not null,
  is_default boolean default false,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Add foreign key back to customers for default_address_id safely if not exists
do $$
begin
  if not exists (
    select 1 from information_schema.table_constraints 
    where constraint_name = 'fk_customers_default_address'
  ) then
    alter table public.customers 
    add constraint fk_customers_default_address 
    foreign key (default_address_id) references public.addresses(id) on delete set null;
  end if;
end $$;

-- 4. Enhance Orders Table with explicit columns requested
-- Ensure columns exist: pickup_address, delivery_address (synonym for dropoff_address),
-- package_description, package_type, delivery_fee, payment_status, order_status, assigned_rider_id
alter table public.orders 
  add column if not exists delivery_address text,
  add column if not exists package_description text,
  add column if not exists delivery_fee numeric,
  add column if not exists order_status text default 'pending',
  add column if not exists assigned_rider_id uuid references public.riders(id) on delete set null,
  add column if not exists updated_at timestamp with time zone default now();

-- Synchronize dropoff_address and delivery_address if needed
update public.orders set delivery_address = dropoff_address where delivery_address is null and dropoff_address is not null;
update public.orders set delivery_fee = price where delivery_fee is null and price is not null;
update public.orders set order_status = status where order_status is null and status is not null;
update public.orders set package_description = description where package_description is null and description is not null;
update public.orders set assigned_rider_id = rider_id where assigned_rider_id is null and rider_id is not null;

-- 5. Enhance Riders Table
-- Columns: id, full_name, phone, vehicle_type, license_plate, current_status, current_lat, current_lng, rating, total_deliveries, total_earnings, created_at
alter table public.riders
  add column if not exists full_name text,
  add column if not exists phone text,
  add column if not exists current_status text default 'offline',
  add column if not exists created_at timestamp with time zone default now(),
  add column if not exists updated_at timestamp with time zone default now();

-- Update current_status from status if needed
update public.riders set current_status = status where current_status is null and status is not null;

-- 6. Enhance Payments Table
-- Columns: id, order_id, amount, payment_method, payment_status, transaction_reference, created_at
alter table public.payments
  add column if not exists payment_method text default 'momo_mtn',
  add column if not exists payment_status text default 'pending',
  add column if not exists transaction_reference text,
  add column if not exists updated_at timestamp with time zone default now();

update public.payments set payment_status = status where payment_status is null and status is not null;
update public.payments set transaction_reference = transaction_ref where transaction_reference is null and transaction_ref is not null;

-- 7. Order Status History Table (Audit log for tracking status lifecycle)
create table if not exists public.order_status_history (
  id uuid primary key default uuid_generate_v4(),
  order_id uuid not null references public.orders(id) on delete cascade,
  status text not null check (status in ('pending', 'accepted', 'picked_up', 'on_the_way', 'delivered', 'cancelled', 'failed')),
  changed_by uuid references public.users(id) on delete set null,
  changed_by_role text,
  notes text,
  metadata jsonb default '{}'::jsonb,
  created_at timestamp with time zone default now()
);

-- 8. Indexes for High Performance
create index if not exists idx_customers_user_id on public.customers(user_id);
create index if not exists idx_customers_phone on public.customers(phone);
create index if not exists idx_addresses_customer_id on public.addresses(customer_id);
create index if not exists idx_addresses_user_id on public.addresses(user_id);
create index if not exists idx_orders_assigned_rider on public.orders(assigned_rider_id);
create index if not exists idx_orders_order_status on public.orders(order_status);
create index if not exists idx_order_status_history_order_id on public.order_status_history(order_id, created_at desc);
create index if not exists idx_payments_order_id on public.payments(order_id);
create index if not exists idx_payments_transaction_ref on public.payments(transaction_reference);

-- 9. Trigger: Automatically Log Order Status Changes to order_status_history
create or replace function public.log_order_status_change()
returns trigger as $$
begin
  if (TG_OP = 'INSERT') or (OLD.status is distinct from NEW.status) or (OLD.order_status is distinct from NEW.order_status) then
    insert into public.order_status_history (
      order_id,
      status,
      changed_by,
      changed_by_role,
      notes
    ) values (
      NEW.id,
      coalesce(NEW.order_status, NEW.status, 'pending'),
      auth.uid(),
      (select role from public.users where id = auth.uid()),
      case 
        when TG_OP = 'INSERT' then 'Order placed initial pending status'
        else 'Order transitioned to ' || coalesce(NEW.order_status, NEW.status)
      end
    );
  end if;

  -- Ensure columns stay in sync
  if NEW.order_status is not null and NEW.status is null then
    NEW.status := NEW.order_status;
  elsif NEW.status is not null and NEW.order_status is null then
    NEW.order_status := NEW.status;
  elsif NEW.order_status is not null then
    NEW.status := NEW.order_status;
  end if;

  if NEW.delivery_fee is not null and NEW.price is null then
    NEW.price := NEW.delivery_fee;
  elsif NEW.price is not null and NEW.delivery_fee is null then
    NEW.delivery_fee := NEW.price;
  end if;

  if NEW.assigned_rider_id is not null and NEW.rider_id is null then
    NEW.rider_id := NEW.assigned_rider_id;
  elsif NEW.rider_id is not null and NEW.assigned_rider_id is null then
    NEW.assigned_rider_id := NEW.rider_id;
  end if;

  NEW.updated_at := now();
  return NEW;
end;
$$ language plpgsql security definer;

drop trigger if exists trigger_order_status_audit on public.orders;
create trigger trigger_order_status_audit
  before insert or update on public.orders
  for each row execute function public.log_order_status_change();

-- 10. Enable Row Level Security (RLS) on all new tables
alter table public.customers enable row level security;
alter table public.addresses enable row level security;
alter table public.order_status_history enable row level security;

-- Customers RLS:
create policy "Users can view own customer record" on public.customers 
  for select using (auth.uid() = user_id or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "Users can update own customer record" on public.customers 
  for update using (auth.uid() = user_id or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

create policy "Users can insert own customer record" on public.customers 
  for insert with check (auth.uid() = user_id or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Addresses RLS:
create policy "Users can manage own addresses" on public.addresses 
  for all using (auth.uid() = user_id or exists (select 1 from public.users where id = auth.uid() and role = 'admin'));

-- Order Status History RLS:
create policy "Authorized parties view order status history" on public.order_status_history
  for select using (
    exists (
      select 1 from public.orders o 
      where o.id = order_status_history.order_id 
      and (
        o.customer_id = auth.uid() 
        or o.rider_id = auth.uid() 
        or o.assigned_rider_id = auth.uid()
        or exists (select 1 from public.users u where u.id = auth.uid() and u.role = 'admin')
      )
    )
  );

create policy "System and riders can insert history" on public.order_status_history
  for insert with check (true);
