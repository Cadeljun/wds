'use client'

export type PaymentMethod = 'momo' | 'card' | 'cash' | 'wallet'

interface PriceCardProps {
  total: number
  km: number
  mins: number
  breakdown: {
    base: number
    distance: number
    packageFee: number
    express: number
  }
  packageType: string
  payType: PaymentMethod
  onPayTypeChange: (type: PaymentMethod) => void
  onOrder: () => void
  walletBalance?: number
  onOpenTopup?: () => void
}

export default function PriceCard({
  total,
  km,
  mins,
  breakdown,
  packageType,
  payType,
  onPayTypeChange,
  onOrder,
  walletBalance = 0,
  onOpenTopup,
}: PriceCardProps) {
  const hasSufficientWallet = walletBalance >= total

  return (
    <div className="bg-black rounded-[32px] p-6 md:p-7 text-white relative overflow-hidden" id="customer-price-card">
      <div className="absolute top-0 right-0 w-[180px] h-[180px] bg-[#FFC700]/20 rounded-full blur-[40px] -mr-12 -mt-12 pointer-events-none"></div>
      <div className="flex items-center justify-between mb-5">
        <div className="text-[11px] font-bold tracking-[0.15em] uppercase text-white/50">Price Estimate</div>
        <div className="px-2.5 py-1 bg-white/10 rounded-full text-[10px] font-bold flex items-center gap-1"><span className="w-1.5 h-1.5 bg-green-400 rounded-full"></span>LIVE PRICING</div>
      </div>
      <div className="flex items-end gap-2">
        <div className="text-[42px] font-extrabold leading-none tracking-tight">GHS {total}</div>
        <div className="text-[13px] text-white/60 mb-2 font-medium">/ delivery</div>
      </div>
      <div className="mt-4 space-y-2 text-[13px]">
        <div className="flex justify-between text-white/60"><span>{km} km • {mins} mins</span><span>GHS {breakdown.base} base</span></div>
        <div className="flex justify-between text-white/60"><span>Package • {packageType}</span><span>GHS {breakdown.packageFee}</span></div>
        <div className="flex justify-between text-white/60"><span>Express fee</span><span>GHS {breakdown.express}</span></div>
        <div className="h-[1px] bg-white/10 my-3"></div>
        <div className="flex justify-between font-semibold text-white"><span>You pay</span><span>GHS {total}</span></div>
      </div>

      <div className="mt-6">
        <div className="flex items-center justify-between mb-3">
          <div className="text-[11px] font-bold tracking-[0.12em] uppercase text-white/40">Payment Method</div>
          {walletBalance > 0 && (
            <span className="text-[10px] text-[#FFC700] font-bold">
              Wallet: GHS {walletBalance.toFixed(2)}
            </span>
          )}
        </div>
        <div className="grid grid-cols-4 gap-2">
          {([
            { id: 'wallet', label: 'Wallet', tag: 'Prepaid' },
            { id: 'momo', label: 'MoMo', tag: 'Instant' },
            { id: 'card', label: 'Card', tag: 'Online' },
            { id: 'cash', label: 'Cash', tag: 'Delivery' },
          ] as const).map(m => (
            <button
              key={m.id}
              type="button"
              onClick={() => onPayTypeChange(m.id as PaymentMethod)}
              className={`rounded-2xl py-3 px-1.5 flex flex-col items-center justify-center border transition ${
                payType === m.id
                  ? 'bg-white text-black border-white shadow-sm'
                  : 'bg-white/10 border-white/10 hover:bg-white/15 text-white'
              }`}
            >
              <span className="text-[12px] font-bold">{m.label}</span>
              <span className={`text-[9px] font-medium uppercase tracking-wider ${payType === m.id ? 'text-black/60' : 'text-white/40'}`}>
                {m.tag}
              </span>
            </button>
          ))}
        </div>

        {/* MoMo Provider Pills */}
        {payType === 'momo' && (
          <div className="grid grid-cols-3 gap-2 mt-2.5">
            <button type="button" className="text-[10px] bg-[#FFC700] text-black font-bold rounded-full py-1.5 uppercase tracking-wide">MTN MoMo</button>
            <button type="button" className="text-[10px] bg-white/10 border border-white/10 rounded-full py-1.5 font-semibold text-white/80 uppercase tracking-wide">Telecel</button>
            <button type="button" className="text-[10px] bg-white/10 border border-white/10 rounded-full py-1.5 font-semibold text-white/80 uppercase tracking-wide">AT Money</button>
          </div>
        )}

        {/* Wallet Balance Feedback */}
        {payType === 'wallet' && (
          <div className="mt-2.5 bg-white/10 rounded-2xl p-3 border border-white/10 text-[12px]">
            {hasSufficientWallet ? (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-emerald-400 font-bold">
                  <span>Available Balance Sufficient</span>
                  <span>GHS {walletBalance.toFixed(2)}</span>
                </div>
                <div className="text-white/60 text-[11px]">
                  GHS {(walletBalance - total).toFixed(2)} remaining after payment. Immediate dispatch confirmation.
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-amber-300 font-bold">
                  <span>Insufficient Balance</span>
                  <span>GHS {walletBalance.toFixed(2)}</span>
                </div>
                <div className="text-white/60 text-[11px]">
                  Requires additional GHS {(total - walletBalance).toFixed(2)} to complete payment.
                </div>
                {onOpenTopup && (
                  <button
                    type="button"
                    onClick={onOpenTopup}
                    className="w-full h-8 bg-[#FFC700] text-black rounded-xl font-bold text-[11px] flex items-center justify-center hover:bg-[#ffcf22] transition"
                  >
                    Top Up Balance via Mobile Money
                  </button>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      <button
        onClick={onOrder}
        disabled={payType === 'wallet' && !hasSufficientWallet}
        className="w-full mt-6 h-[54px] bg-[#FFC700] text-black rounded-full font-bold text-[14px] flex items-center justify-center hover:brightness-110 active:scale-[0.99] transition disabled:opacity-50 disabled:cursor-not-allowed shadow-md uppercase tracking-wider"
      >
        {payType === 'wallet' ? (
          hasSufficientWallet ? (
            <>Pay GHS {total} from Wallet & Dispatch</>
          ) : (
            <>Top Up Wallet to Continue</>
          )
        ) : (
          <>Request Courier Dispatch</>
        )}
      </button>
      <div className="text-[11px] text-white/40 text-center mt-3">
        {payType === 'wallet' ? 'Prepaid cashless settlement • Insured up to GHS 2,000' : 'Paystack secured • Insured up to GHS 2,000'}
      </div>
    </div>
  )
}
