'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import dynamic from 'next/dynamic'
import { useRealtimeData } from '@/lib/use-realtime'

const MapComponent = dynamic(() => import('@/components/Map'), {
  ssr: false,
  loading: () => (
    <div className="h-[380px] bg-[#F5F5F7] rounded-xl flex items-center justify-center text-[12px] text-black/40">
      Initializing live delivery map...
    </div>
  ),
})

export default function OrderTrackingPage({ orderId }: { orderId?: string }) {
  const params = useParams()
  const router = useRouter()
  const id = orderId || (params as any)?.id
  const { allOrders, riders, isConnected, lastEventAt } = useRealtimeData()

  const [order, setOrder] = useState<any>(null)
  const [history, setHistory] = useState<any[]>([])
  const [forbidden, setForbidden] = useState(false)
  const [session, setSession] = useState<any>(null)

  useEffect(() => {
    // Check session
    const savedSession = localStorage.getItem('wds_session_v2')
    const userSession = savedSession ? JSON.parse(savedSession) : null
    setSession(userSession)

    // Fetch database status history
    fetch(`/api/orders/${id}/history`, {
      headers: userSession ? { 'Authorization': `Bearer demo-token-${userSession.id}-${userSession.role}` } : {}
    })
      .then(res => res.json())
      .then(data => {
        if (data?.history?.length > 0) setHistory(data.history)
      })
      .catch(() => {})

    // 1. First check server-authoritative live stream
    let found = allOrders.find(o => o.id === id || o.orderCode === id)

    // 2. Fallback to localStorage cache
    if (!found && typeof window !== 'undefined') {
      const localOrders = JSON.parse(localStorage.getItem('wds_orders_v2') || '[]')
      found = localOrders.find((o: any) => o.id === id)
    }

    if (!found) {
      // Try to fetch from API directly
      fetch(`/api/orders/${id}/status`)
        .then(res => res.json())
        .then(data => {
          if (data?.order) setOrder(data.order)
        })
        .catch(() => {})
      return
    }

    // Access control: verify customer, assigned rider, or admin
    if (userSession) {
      const isOwner = found.customerId === userSession.id || (found as any).customer_id === userSession.id
      const isAssignedRider = found.riderId === userSession.id || (found as any).rider_id === userSession.id
      const isAdmin = userSession.role === 'admin'
      const isPending = found.status === 'pending'

      if (userSession.role === 'customer' && !isOwner && !isAdmin) {
        setForbidden(true)
        return
      }
      if (userSession.role === 'rider' && !isAssignedRider && !isPending && !isAdmin) {
        setForbidden(true)
        return
      }
    }

    setOrder(found)
  }, [id, allOrders])

  if (forbidden) {
    return (
      <div className="min-h-screen bg-[#F5F5F7] flex items-center justify-center p-8">
        <div className="bg-white rounded-[24px] p-8 border border-red-200 text-center max-w-[400px]">
          <div className="w-12 h-12 bg-red-50 rounded-full flex items-center justify-center mx-auto mb-4 text-[20px]">🚫</div>
          <h2 className="font-bold text-[18px]">Access Restricted</h2>
          <p className="text-[13px] text-black/60 mt-2">
            You do not have permission to view delivery {id}. Customer accounts can only view their own deliveries.
          </p>
          <button onClick={() => router.push('/')} className="mt-4 h-9 px-4 bg-black text-white rounded-full text-[13px] font-bold">
            Back to Dashboard
          </button>
        </div>
      </div>
    )
  }

  if (!order) {
    return (
      <div className="min-h-screen bg-[#F5F5F7] flex items-center justify-center p-8">
        <div className="bg-white rounded-[24px] p-8 border border-black/5 text-center max-w-[400px]">
          <div className="w-8 h-8 border-2 border-black border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <div className="font-bold text-[16px]">Connecting to Live Dispatch...</div>
          <p className="text-[12px] text-black/50 mt-1">Retrieving active telemetry for {id}</p>
        </div>
      </div>
    )
  }

  // Find assigned rider location if available
  const activeRider = riders.find(r => r.riderId === order.riderId)
  const riderLocation = activeRider
    ? { lat: activeRider.lat, lng: activeRider.lng }
    : { lat: 5.5800, lng: -0.2100 }

  const pickupLocation = order.pickupCoords || { lat: 5.6365, lng: -0.1645 }
  const dropoffLocation = order.dropoffCoords || { lat: 5.5560, lng: -0.1760 }

  const isDelivered = order.status === 'delivered'
  const isOnWay = order.status === 'on_the_way'
  const isPickedUp = order.status === 'picked_up' || isOnWay || isDelivered

  return (
    <div className="min-h-screen bg-[#F5F5F7]">
      <header className="h-[64px] bg-white/90 backdrop-blur-md border-b border-black/5 flex items-center justify-between px-4 md:px-8 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-black text-[#FFC700] rounded-xl flex items-center justify-center font-bold">W</div>
          <span className="font-bold">WDS Live Tracking</span>
          <span className="ml-2 px-2.5 py-0.5 bg-[#FFC700] rounded-full text-[11px] font-bold">{order.id}</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3 py-1 bg-white rounded-full border border-black/10 text-[11px]">
            <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-amber-400'}`}></span>
            <span className="font-semibold text-black/80">{isConnected ? 'Live Telemetry' : 'Reconnecting...'}</span>
            {lastEventAt && <span className="text-black/40">({lastEventAt})</span>}
          </div>
          <button onClick={() => router.push('/')} className="h-9 px-4 bg-black/5 hover:bg-black/10 rounded-full text-[13px] font-bold transition">
            Back
          </button>
        </div>
      </header>

      <div className="max-w-[1100px] mx-auto px-4 md:px-8 py-8">
        <div className="bg-white rounded-[28px] p-6 border border-black/5 shadow-[0_20px_60px_rgba(0,0,0,0.05)]">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6 pb-4 border-b border-black/5">
            <div>
              <h1 className="font-extrabold text-[20px] tracking-tight">Delivery #{order.id}</h1>
              <div className="text-[13px] text-black/50 mt-0.5">Dispatched in Greater Accra • Real-time tracking</div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-[12px] font-bold capitalize ${
                isDelivered ? 'bg-green-100 text-green-800' : 'bg-[#FFC700] text-black'
              }`}>
                {order.status.replace(/_/g, ' ')}
              </span>
            </div>
          </div>

          <div className="grid lg:grid-cols-[340px_1fr] gap-6">
            <div className="space-y-5">
              <div className="p-4 bg-[#F5F5F7] rounded-2xl flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-black text-[#FFC700] flex items-center justify-center text-[20px]">
                  🏍️
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[14px] font-bold truncate">{order.riderName || 'Kwame Asare (Assigned)'}</div>
                  <div className="text-[11px] text-black/60">Verified Courier • Greater Accra Dispatch</div>
                </div>
                <button
                  onClick={() => alert(`Calling courier directly at +233 24 498 7654`)}
                  className="px-3 py-1.5 bg-black text-white rounded-full text-[11px] font-bold hover:bg-black/80 transition"
                >
                  Call
                </button>
              </div>

              {/* Real-time status progression */}
              <div className="relative pl-7 py-2">
                <div className="absolute left-2.5 top-3 bottom-3 w-[2px] bg-black/10"></div>
                <div className="space-y-6 text-[13px]">
                  <div className="flex gap-3 items-start">
                    <div className="w-5 h-5 -ml-6 rounded-full bg-green-500 flex items-center justify-center text-white text-[10px] font-bold">
                      ✓
                    </div>
                    <div>
                      <div className="font-bold">Order Received</div>
                      <div className="text-black/50 text-[11px]">System recorded and broadcasted</div>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    <div className={`w-5 h-5 -ml-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isPickedUp ? 'bg-green-500 text-white' : 'bg-black/10 text-black/40'
                    }`}>
                      {isPickedUp ? '✓' : '•'}
                    </div>
                    <div>
                      <div className="font-bold">Package Picked Up</div>
                      <div className="text-black/50 text-[11px]">{order.pickup}</div>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    <div className={`w-5 h-5 -ml-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isOnWay ? 'bg-[#FFC700] animate-pulse text-black' : isDelivered ? 'bg-green-500 text-white' : 'bg-black/10 text-black/40'
                    }`}>
                      {isDelivered ? '✓' : '•'}
                    </div>
                    <div>
                      <div className="font-bold">Transit & Live GPS</div>
                      <div className="text-black/50 text-[11px]">
                        {isOnWay ? `${order.etaMinutes || 12} mins estimated arrival` : isDelivered ? 'Completed' : 'En route to pickup'}
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-3 items-start">
                    <div className={`w-5 h-5 -ml-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                      isDelivered ? 'bg-green-500 text-white' : 'bg-black/10 text-black/40'
                    }`}>
                      {isDelivered ? '✓' : '•'}
                    </div>
                    <div>
                      <div className="font-bold">Delivered to Recipient</div>
                      <div className="text-black/50 text-[11px]">{order.dropoff}</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Database Status Audit Log */}
              {history.length > 0 && (
                <div className="bg-white border border-black/5 rounded-2xl p-4 text-[12px]">
                  <div className="text-[10px] uppercase font-bold text-black/40 mb-2 tracking-wider">Database Status Log</div>
                  <div className="space-y-2">
                    {history.map((h: any, i: number) => (
                      <div key={h.id || i} className="flex items-center justify-between border-b border-black/[0.03] pb-1.5 last:border-0 last:pb-0">
                        <div>
                          <span className="font-bold uppercase tracking-tight text-[11px] bg-black/5 px-2 py-0.5 rounded-full mr-2">
                            {h.status}
                          </span>
                          <span className="text-black/60 text-[11px]">{h.notes || 'Status changed'}</span>
                        </div>
                        <span className="text-[10px] text-black/40 whitespace-nowrap">
                          {new Date(h.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Order specifics */}
              <div className="bg-[#F5F5F7] rounded-2xl p-4 text-[13px] space-y-2">
                <div className="text-[11px] uppercase font-bold text-black/40 mb-1">Route & Delivery Info</div>
                <div className="flex justify-between"><span className="text-black/50">Pickup:</span><span className="font-bold text-right truncate max-w-[180px]">{order.pickup}</span></div>
                <div className="flex justify-between"><span className="text-black/50">Dropoff:</span><span className="font-bold text-right truncate max-w-[180px]">{order.dropoff}</span></div>
                <div className="flex justify-between"><span className="text-black/50">Package:</span><span className="font-semibold capitalize">{order.type}</span></div>
                <div className="flex justify-between"><span className="text-black/50">Amount:</span><span className="font-bold text-black">{order.price}</span></div>
                <div className="flex justify-between items-center">
                  <span className="text-black/50">Payment:</span>
                  <span className="font-bold flex items-center gap-1.5">
                    {order.paymentMethod?.includes('Wallet') ? (
                      <span className="inline-flex items-center gap-1 bg-[#FFC700]/20 text-black px-2 py-0.5 rounded-md text-[12px] font-extrabold">
                        <span>⚡</span>
                        <span>Prepaid Wallet</span>
                      </span>
                    ) : (
                      <span>{order.paymentMethod || 'Mobile Money (MoMo)'}</span>
                    )}
                  </span>
                </div>
              </div>
            </div>

            {/* Map & Live telemetry container */}
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-2 border border-black/5 shadow-inner">
                <MapComponent
                  pickup={pickupLocation}
                  dropoff={dropoffLocation}
                  rider={riderLocation}
                  height="380px"
                />
              </div>

              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="bg-[#F5F5F7] rounded-xl p-3 border border-black/5">
                  <div className="text-[11px] text-black/50 uppercase font-semibold">Total Fare</div>
                  <div className="font-extrabold text-[16px] mt-0.5">{order.price}</div>
                </div>
                <div className="bg-[#F5F5F7] rounded-xl p-3 border border-black/5">
                  <div className="text-[11px] text-black/50 uppercase font-semibold">Distance</div>
                  <div className="font-extrabold text-[16px] mt-0.5">{order.distanceKm ? `${order.distanceKm} km` : '7.2 km'}</div>
                </div>
                <div className="bg-[#F5F5F7] rounded-xl p-3 border border-black/5">
                  <div className="text-[11px] text-black/50 uppercase font-semibold">Live ETA</div>
                  <div className="font-extrabold text-[16px] text-green-700 mt-0.5">
                    {order.status === 'delivered' ? 'Delivered' : `${order.etaMinutes || 12} mins`}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
