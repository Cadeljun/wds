'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { RouteLoadingFallback, MapLoadingFallback } from '@/components/RouteLoadingFallback'
import CustomerWallet, { WalletTransaction } from '@/components/views/CustomerWallet'
import { PaymentMethod } from '@/components/PriceCard'

// Heavy dependencies - lazy loaded
const MapComponent = dynamic(() => import('@/components/Map'), { 
  ssr: false,
  loading: () => <MapLoadingFallback />
})

const PriceCard = dynamic(() => import('@/components/PriceCard'), {
  loading: () => <div className="h-[400px] bg-black rounded-[32px] animate-pulse" />
})

type PackageType = 'parcel' | 'food' | 'grocery' | 'medicine' | 'document' | 'other'

const pkgTypes = [
  { id: 'parcel' as PackageType, label: 'Parcel', icon: '📦' },
  { id: 'food' as PackageType, label: 'Food', icon: '🍔' },
  { id: 'grocery' as PackageType, label: 'Grocery', icon: '🛒' },
  { id: 'medicine' as PackageType, label: 'Medicine', icon: '💊' },
  { id: 'document' as PackageType, label: 'Document', icon: '📄' },
  { id: 'other' as PackageType, label: 'Other', icon: '⋯' },
]

interface CustomerViewProps {
  currentUser: any
  orders: any[]
  onPlaceOrder: (data: any) => void
  onTrack: (order: any) => void
}

export default function CustomerView({ currentUser, orders, onPlaceOrder, onTrack }: CustomerViewProps) {
  const [activeTab, setActiveTab] = useState<'delivery' | 'wallet' | 'orders'>('delivery')
  const [pkgType, setPkgType] = useState<PackageType>('parcel')
  const [payType, setPayType] = useState<PaymentMethod>('wallet')
  const [pickup, setPickup] = useState('East Legon, American House')
  const [dropoff, setDropoff] = useState('Osu, Oxford Street')
  const [itemDesc, setItemDesc] = useState('')
  const [recipientName, setRecipientName] = useState('')
  const [recipientPhone, setRecipientPhone] = useState('')
  const [express, setExpress] = useState(false)

  // Customer Wallet State
  const walletStorageKey = `wds_cust_wallet_${currentUser?.id || currentUser?.phone || 'guest'}`
  const [walletBalance, setWalletBalance] = useState<number>(125.00)
  const [walletTransactions, setWalletTransactions] = useState<WalletTransaction[]>([])
  const [showTopupModal, setShowTopupModal] = useState(false)
  const [toastMessage, setToastMessage] = useState<string | null>(null)

  // Initialize and persist wallet
  useEffect(() => {
    try {
      const saved = localStorage.getItem(walletStorageKey)
      if (saved) {
        const parsed = JSON.parse(saved)
        if (typeof parsed.balance === 'number') setWalletBalance(parsed.balance)
        if (Array.isArray(parsed.transactions)) setWalletTransactions(parsed.transactions)
      } else {
        // Initial seed transactions
        const initialTxns: WalletTransaction[] = [
          {
            id: 'TXN-8801',
            type: 'momo_topup',
            title: 'MTN Mobile Money Top-Up',
            amount: 100.00,
            date: 'Today 10:30 AM',
            status: 'completed',
            reference: 'MM-TOP-88012',
            network: 'MTN MoMo',
            phone: currentUser?.phone || '0244 123 456',
          },
          {
            id: 'TXN-8742',
            type: 'delivery_payment',
            title: 'Delivery Fare #WDS-88 (Adabraka → Tema)',
            amount: -45.00,
            date: 'Yesterday 04:15 PM',
            status: 'completed',
            reference: 'WAL-PAY-87420',
            orderId: 'WDS-88',
          },
          {
            id: 'TXN-8690',
            type: 'momo_topup',
            title: 'Telecel Cash Top-Up',
            amount: 70.00,
            date: '16 Sep 02:00 PM',
            status: 'completed',
            reference: 'MM-TOP-86904',
            network: 'Telecel Cash',
            phone: currentUser?.phone || '0244 123 456',
          },
        ]
        setWalletBalance(125.00)
        setWalletTransactions(initialTxns)
        localStorage.setItem(walletStorageKey, JSON.stringify({ balance: 125.00, transactions: initialTxns }))
      }
    } catch (e) {
      console.error('Failed to load wallet from storage', e)
    }
  }, [walletStorageKey, currentUser?.phone])

  function saveWallet(newBalance: number, newTxns: WalletTransaction[]) {
    setWalletBalance(newBalance)
    setWalletTransactions(newTxns)
    try {
      localStorage.setItem(walletStorageKey, JSON.stringify({ balance: newBalance, transactions: newTxns }))
    } catch (e) {
      console.error('Failed to save wallet to storage', e)
    }
  }

  function handleTopupSuccess(amount: number, network: string, phone: string) {
    const newBalance = walletBalance + amount
    const newTxn: WalletTransaction = {
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      type: 'momo_topup',
      title: `${network} Wallet Top-Up`,
      amount,
      date: 'Just now',
      status: 'completed',
      reference: 'MM-TOP-' + Math.floor(10000 + Math.random() * 90000),
      network,
      phone,
    }
    const updatedTxns = [newTxn, ...walletTransactions]
    saveWallet(newBalance, updatedTxns)

    setToastMessage(`✓ Successfully added GHS ${amount.toFixed(2)} via ${network}!`)
    setTimeout(() => setToastMessage(null), 4000)

    // Optional API sync
    fetch('/api/wallet', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer demo-token-${currentUser?.id || 'guest'}-customer`,
      },
      body: JSON.stringify({
        amount,
        network: network.toLowerCase().includes('mtn') ? 'mtn' : network.toLowerCase().includes('telecel') ? 'telecel' : 'airteltigo',
        phone,
      }),
    }).catch(() => {})
  }

  // Real geocode + pricing simulation
  const price = { 
    total: 42, 
    km: 8.4, 
    mins: 22, 
    breakdown: { base: 15, distance: 21, packageFee: 7, express: express ? 8 : 0 } 
  }

  function handleOrder() {
    if (payType === 'wallet') {
      if (walletBalance < price.total) {
        alert(`Insufficient wallet balance (GHS ${walletBalance.toFixed(2)}). Please top up via MoMo.`)
        setShowTopupModal(true)
        return
      }

      // Deduct from wallet
      const newBal = walletBalance - price.total
      const newTxn: WalletTransaction = {
        id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
        type: 'delivery_payment',
        title: `Delivery Fare (${pickup.split(',')[0]} → ${dropoff.split(',')[0]})`,
        amount: -price.total,
        date: 'Just now',
        status: 'completed',
        reference: 'WAL-PAY-' + Math.floor(10000 + Math.random() * 90000),
        orderId: 'WDS-' + (orders.length + 101),
      }
      saveWallet(newBal, [newTxn, ...walletTransactions])

      setToastMessage(`✓ Paid GHS ${price.total}.00 with Virtual Wallet! GHS ${newBal.toFixed(2)} remaining.`)
      setTimeout(() => setToastMessage(null), 4500)

      // Optional API sync
      fetch('/api/wallet', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer demo-token-${currentUser?.id || 'guest'}-customer`,
        },
        body: JSON.stringify({
          action: 'pay',
          amount: price.total,
          title: `Delivery Fare (${pickup.split(',')[0]} → ${dropoff.split(',')[0]})`,
          orderId: 'WDS-' + (orders.length + 101),
        }),
      }).catch(() => {})
    }

    onPlaceOrder({
      pickup, 
      dropoff, 
      type: pkgType, 
      description: itemDesc,
      recipientName, 
      recipientPhone, 
      price: `GHS ${price.total}`,
      paymentMethod: payType === 'wallet' ? 'Virtual Wallet (Prepaid)' : payType,
    })
  }

  return (
    <div className="pb-16" id="customer-view-root">
      {/* Toast notification banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-black text-white px-5 py-3.5 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-white/10 flex items-center gap-3 animate-in slide-in-from-bottom-5 duration-300">
          <span className="text-[#FFC700] text-[18px] font-black">₵</span>
          <span className="text-[13px] font-bold">{toastMessage}</span>
          <button onClick={() => setToastMessage(null)} className="text-white/40 hover:text-white text-[12px] ml-2">✕</button>
        </div>
      )}

      {/* Customer Navigation Bar */}
      <div className="border-b border-black/5 bg-white/70 backdrop-blur-md sticky top-[64px] z-30">
        <div className="max-w-[1440px] mx-auto px-4 md:px-8 py-3 flex flex-wrap items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex bg-[#F5F5F7] p-1 rounded-2xl border border-black/5" id="customer-nav-tabs">
            <button
              onClick={() => setActiveTab('delivery')}
              className={`h-10 px-4 md:px-5 rounded-xl text-[12px] font-extrabold transition flex items-center gap-2 ${
                activeTab === 'delivery'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-black/60 hover:text-black'
              }`}
            >
              <span>📦</span>
              <span>Send Package</span>
            </button>

            <button
              id="tab-customer-virtual-wallet"
              onClick={() => setActiveTab('wallet')}
              className={`h-10 px-4 md:px-5 rounded-xl text-[12px] font-extrabold transition flex items-center gap-2 ${
                activeTab === 'wallet'
                  ? 'bg-black text-white shadow-sm'
                  : 'text-black/60 hover:text-black'
              }`}
            >
              <span className="text-[#FFC700]">⚡</span>
              <span>Virtual Wallet</span>
              <span className={`text-[11px] px-2 py-0.5 rounded-full font-bold ml-1 ${
                activeTab === 'wallet' ? 'bg-white/20 text-[#FFC700]' : 'bg-black/5 text-black'
              }`}>
                GHS {walletBalance.toFixed(2)}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`h-10 px-4 md:px-5 rounded-xl text-[12px] font-extrabold transition flex items-center gap-2 ${
                activeTab === 'orders'
                  ? 'bg-white text-black shadow-sm'
                  : 'text-black/60 hover:text-black'
              }`}
            >
              <span>📋</span>
              <span>Orders ({orders.length})</span>
            </button>
          </div>

          {/* Quick Wallet Pill on top right */}
          <div className="flex items-center gap-2">
            <div className="bg-[#F5F5F7] border border-black/5 rounded-2xl px-3.5 py-1.5 flex items-center gap-2.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <div className="text-[12px]">
                <span className="text-black/50 font-medium">Wallet Balance: </span>
                <span className="font-extrabold text-black">GHS {walletBalance.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => setShowTopupModal(true)}
              className="h-9 px-3.5 bg-[#FFC700] hover:bg-[#ffcf22] active:scale-[0.98] text-black font-extrabold text-[11px] rounded-full flex items-center gap-1.5 transition shadow-sm"
            >
              <span>📱</span>
              <span>Top Up MoMo</span>
            </button>
          </div>
        </div>
      </div>

      {/* TAB 1: Send Package Form & Price Card */}
      {activeTab === 'delivery' && (
        <section className="max-w-[1440px] mx-auto px-4 md:px-8 py-6 grid lg:grid-cols-[1.15fr_0.85fr] gap-6">
          <div className="bg-white rounded-[32px] p-5 md:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.06)] border border-black/[0.04]">
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <h1 className="font-extrabold text-[24px] md:text-[32px] leading-[0.95]">
                Deliver anything in <span className="bg-[#FFC700] px-1">Accra</span> now.
              </h1>
            </div>
            <p className="text-[13px] text-black/60">
              Welcome {currentUser?.name || 'Customer'} • Pay with Virtual Wallet or MoMo • Instant dispatch
            </p>
            
            {/* Quick Wallet Perks Banner */}
            <div className="mt-5 p-3.5 bg-gradient-to-r from-[#F5F5F7] to-white rounded-2xl border border-black/5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <span className="text-[18px]">⚡</span>
                <span className="text-[12px] font-bold text-black/80">
                  Virtual Wallet Active • Balance: <span className="text-black font-extrabold">GHS {walletBalance.toFixed(2)}</span>
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowTopupModal(true)}
                className="text-[11px] font-extrabold text-black hover:underline flex items-center gap-1"
              >
                <span>+ Top Up Funds</span>
              </button>
            </div>

            <div className="mt-6">
              <label className="text-[11px] font-bold uppercase text-black/50 mb-2 block">What are you sending?</label>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                {pkgTypes.map(p => (
                  <button 
                    key={p.id} 
                    type="button"
                    onClick={() => setPkgType(p.id)} 
                    className={`rounded-2xl p-3 flex flex-col items-center gap-2 border transition ${
                      pkgType === p.id ? 'bg-black text-white border-black shadow-sm' : 'bg-white border-black/10 hover:bg-black/5'
                    }`}
                  >
                    <span className="text-[18px]">{p.icon}</span>
                    <span className="text-[11px] font-semibold">{p.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 space-y-3">
              <div>
                <label className="text-[11px] font-bold uppercase text-black/50 mb-1 block">Pickup Address</label>
                <input 
                  value={pickup} 
                  onChange={e => setPickup(e.target.value)} 
                  placeholder="Pickup" 
                  className="w-full h-[52px] bg-[#F5F5F7] border border-black/5 rounded-2xl px-4 text-[14px] font-medium focus:bg-white focus:border-black transition" 
                />
              </div>
              <div>
                <label className="text-[11px] font-bold uppercase text-black/50 mb-1 block">Drop-off Destination</label>
                <input 
                  value={dropoff} 
                  onChange={e => setDropoff(e.target.value)} 
                  placeholder="Drop-off" 
                  className="w-full h-[52px] bg-white border-2 border-black rounded-2xl px-4 text-[14px] font-bold transition" 
                />
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                <input 
                  value={itemDesc} 
                  onChange={e => setItemDesc(e.target.value)} 
                  placeholder="What are you sending? (e.g. food, keys, box)" 
                  className="h-[48px] bg-[#F5F5F7] border border-black/5 rounded-2xl px-4 text-[13px] focus:bg-white focus:border-black transition" 
                />
                <div className="flex gap-2">
                  <input 
                    value={recipientName} 
                    onChange={e => setRecipientName(e.target.value)} 
                    placeholder="Recipient name" 
                    className="h-[48px] bg-[#F5F5F7] border border-black/5 rounded-2xl px-4 text-[13px] w-1/2 focus:bg-white focus:border-black transition" 
                  />
                  <input 
                    value={recipientPhone} 
                    onChange={e => setRecipientPhone(e.target.value)} 
                    placeholder="0244..." 
                    className="h-[48px] bg-[#F5F5F7] border border-black/5 rounded-2xl px-4 text-[13px] w-1/2 focus:bg-white focus:border-black transition" 
                  />
                </div>
              </div>
              <label className="flex items-center gap-2 mt-3 cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={express} 
                  onChange={e => setExpress(e.target.checked)} 
                  className="rounded accent-black" 
                />
                <span className="text-[13px] font-bold">Express Priority Dispatch +GHS 8 (35-50 mins)</span>
              </label>
            </div>
          </div>

          <div className="space-y-6">
            <PriceCard 
              total={price.total} 
              km={price.km} 
              mins={price.mins} 
              breakdown={price.breakdown} 
              packageType={pkgType}
              payType={payType}
              onPayTypeChange={setPayType}
              onOrder={handleOrder}
              walletBalance={walletBalance}
              onOpenTopup={() => setShowTopupModal(true)}
            />
            <div className="bg-white rounded-[32px] p-2 border border-black/5">
              <MapComponent 
                pickup={{ lat: 5.6365, lng: -0.1645 }} 
                dropoff={{ lat: 5.5560, lng: -0.1760 }} 
                height="260px"
              />
            </div>
          </div>
        </section>
      )}

      {/* TAB 2: Dedicated Virtual Wallet Section */}
      {activeTab === 'wallet' && (
        <section className="max-w-[1440px] mx-auto px-4 md:px-8 py-6">
          <CustomerWallet 
            currentUser={currentUser}
            balance={walletBalance}
            transactions={walletTransactions}
            onTopupSuccess={handleTopupSuccess}
            showTopupModal={showTopupModal}
            setShowTopupModal={setShowTopupModal}
            onNavigateToSend={() => setActiveTab('delivery')}
          />
        </section>
      )}

      {/* TAB 3: Recent Deliveries */}
      {(activeTab === 'orders' || activeTab === 'delivery') && (
        <section className="max-w-[1440px] mx-auto px-4 md:px-8 pt-4 pb-12">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-[18px]">Recent Deliveries</h3>
              <p className="text-[12px] text-black/50">Tracking and payment history for your dispatches</p>
            </div>
            <span className="text-[12px] text-black/50 font-medium">Auto-syncing live status</span>
          </div>

          {orders.length === 0 ? (
            <div className="bg-white rounded-[24px] p-8 border border-black/5 text-center">
              <div className="text-[32px] mb-2">📦</div>
              <div className="font-bold text-[15px]">No deliveries yet</div>
              <p className="text-[12px] text-black/50 mt-1">Place your first order above using your Virtual Wallet balance.</p>
            </div>
          ) : (
            <div className="grid md:grid-cols-3 gap-4">
              {orders.slice(0, 6).map((o: any) => (
                <div 
                  key={o.id} 
                  className="bg-white rounded-[24px] p-5 border border-black/5 hover:shadow-lg transition cursor-pointer flex flex-col justify-between" 
                  onClick={() => onTrack(o)}
                >
                  <div>
                    <div className="flex justify-between items-start mb-3">
                      <span className="text-[11px] font-bold px-2.5 py-1 rounded-full bg-black/5 text-black">
                        {o.status}
                      </span>
                      <span className="text-[11px] text-black/40">{o.date}</span>
                    </div>
                    <div className="text-[14px] font-extrabold text-black line-clamp-1">
                      {o.pickup} → {o.dropoff}
                    </div>
                    <div className="text-[12px] text-black/50 mt-1 flex items-center justify-between">
                      <span className="capitalize">{o.type}</span>
                      <span className="font-extrabold text-black">{o.price}</span>
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-black/5 flex items-center justify-between text-[11px]">
                    <span className="text-black/40">Payment:</span>
                    <span className="font-bold text-black flex items-center gap-1">
                      {o.paymentMethod?.includes('Wallet') ? (
                        <>
                          <span className="text-[#FFC700]">⚡</span>
                          <span>Prepaid Wallet</span>
                        </>
                      ) : (
                        <span>{o.paymentMethod || 'Mobile Money'}</span>
                      )}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {/* Standalone Top-up Modal when opened from quick buttons while on delivery tab */}
      {activeTab !== 'wallet' && showTopupModal && (
        <CustomerWallet 
          currentUser={currentUser}
          balance={walletBalance}
          transactions={walletTransactions}
          onTopupSuccess={handleTopupSuccess}
          showTopupModal={showTopupModal}
          setShowTopupModal={setShowTopupModal}
        />
      )}
    </div>
  )
}
