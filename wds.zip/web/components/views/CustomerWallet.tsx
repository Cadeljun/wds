'use client'

import { useState } from 'react'

export interface WalletTransaction {
  id: string
  type: 'momo_topup' | 'delivery_payment' | 'refund'
  title: string
  amount: number
  date: string
  status: 'completed' | 'pending' | 'failed'
  reference: string
  network?: string
  phone?: string
  orderId?: string
}

interface CustomerWalletProps {
  currentUser: any
  balance: number
  transactions: WalletTransaction[]
  onTopupSuccess: (amount: number, network: string, phone: string) => void
  showTopupModal: boolean
  setShowTopupModal: (show: boolean) => void
  onNavigateToSend?: () => void
  lastSyncTime?: string
  onRefresh?: () => void
  isLiveConnected?: boolean
}

export default function CustomerWallet({
  currentUser,
  balance,
  transactions,
  onTopupSuccess,
  showTopupModal,
  setShowTopupModal,
  onNavigateToSend,
  lastSyncTime,
  onRefresh,
  isLiveConnected = true,
}: CustomerWalletProps) {
  // Top-up state
  const [topupAmount, setTopupAmount] = useState<string>('50')
  const [momoNetwork, setMomoNetwork] = useState<'mtn' | 'telecel' | 'airteltigo'>('mtn')
  const [momoPhone, setMomoPhone] = useState<string>(currentUser?.phone || '0244 123 456')
  const [filterType, setFilterType] = useState<'all' | 'momo_topup' | 'delivery_payment'>('all')
  const [searchQuery, setSearchQuery] = useState('')

  // USSD Simulator State
  const [ussdStep, setUssdStep] = useState<'form' | 'prompt' | 'success'>('form')
  const [momoPin, setMomoPin] = useState('')
  const [isProcessingUssd, setIsProcessingUssd] = useState(false)
  const [selectedReceipt, setSelectedReceipt] = useState<WalletTransaction | null>(null)
  const [autoPayEnabled, setAutoPayEnabled] = useState(true)

  const presetAmounts = [20, 50, 100, 200, 500]

  // Filtered transactions
  const filteredTransactions = transactions.filter(t => {
    if (filterType !== 'all' && t.type !== filterType) return false
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      return (
        t.title.toLowerCase().includes(q) ||
        t.reference.toLowerCase().includes(q) ||
        (t.orderId && t.orderId.toLowerCase().includes(q))
      )
    }
    return true
  })

  // Computations
  const totalDeposited = transactions
    .filter(t => t.type === 'momo_topup' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0)

  const totalSpent = Math.abs(
    transactions
      .filter(t => t.type === 'delivery_payment' && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0)
  )

  const deliveryPaymentCount = transactions.filter(t => t.type === 'delivery_payment').length

  function handleStartTopup(e: React.FormEvent) {
    e.preventDefault()
    const amt = parseFloat(topupAmount)
    if (isNaN(amt) || amt < 5) {
      alert('Minimum top-up amount is GHS 5.00')
      return
    }
    // Transition to USSD phone prompt simulation
    setUssdStep('prompt')
    setMomoPin('')
  }

  function handleConfirmUssd() {
    if (momoPin.length < 4) {
      alert('Please enter your 4-digit Mobile Money PIN')
      return
    }

    setIsProcessingUssd(true)

    // Realistic network delay
    setTimeout(() => {
      setIsProcessingUssd(false)
      const amt = parseFloat(topupAmount)
      const networkLabel = momoNetwork === 'mtn' ? 'MTN MoMo' : momoNetwork === 'telecel' ? 'Telecel Cash' : 'AT Money'
      onTopupSuccess(amt, networkLabel, momoPhone)
      setUssdStep('success')
    }, 1200)
  }

  function handleCloseModal() {
    setShowTopupModal(false)
    setUssdStep('form')
    setMomoPin('')
    setIsProcessingUssd(false)
  }

  return (
    <div className="space-y-8" id="customer-virtual-wallet">
      {/* Top Banner Cards */}
      <div className="grid lg:grid-cols-[1.2fr_0.8fr] gap-6">
        {/* Main Wallet Balance Card */}
        <div className="bg-black text-white rounded-[32px] p-6 md:p-8 relative overflow-hidden shadow-[0_24px_50px_rgba(0,0,0,0.2)]">
          {/* Subtle gold decorative glow */}
          <div className="absolute top-0 right-0 w-[240px] h-[240px] bg-[#FFC700]/15 rounded-full blur-[50px] -mr-16 -mt-16 pointer-events-none" />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/60">
                Prepaid Virtual Account
              </span>
            </div>
            <span className="text-[11px] bg-white/10 px-3 py-1 rounded-full font-bold text-white/80">
              Instant MoMo Settlement
            </span>
          </div>

          <div className="mt-6">
            <div className="text-[13px] text-white/60 font-medium">Available Wallet Balance</div>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-[44px] md:text-[54px] font-black leading-none tracking-tight">
                GHS {balance.toFixed(2)}
              </span>
              <span className="text-[14px] text-[#FFC700] font-bold">Ghana Cedis</span>
            </div>
          </div>

          <div className="mt-8 flex flex-wrap items-center gap-3 pt-6 border-t border-white/10">
            <button
              id="wallet-topup-momo-btn"
              onClick={() => {
                setUssdStep('form')
                setShowTopupModal(true)
              }}
              className="h-[48px] px-6 bg-[#FFC700] text-black font-extrabold text-[13px] rounded-full flex items-center justify-center hover:bg-[#ffcf22] active:scale-[0.98] transition shadow-md uppercase tracking-wider"
            >
              Top Up Balance via MoMo
            </button>

            {onNavigateToSend && (
              <button
                onClick={onNavigateToSend}
                className="h-[48px] px-6 bg-white/10 text-white font-bold text-[13px] rounded-full flex items-center justify-center hover:bg-white/20 active:scale-[0.98] transition border border-white/10 uppercase tracking-wider"
              >
                Send Package with Balance
              </button>
            )}
          </div>
        </div>

        {/* Quick Insights & Auto-Debit Preference */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-1 gap-4">
          <div className="bg-white rounded-[24px] p-5 border border-black/5 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-black/40">Total MoMo Inflow</span>
                <div className="text-[24px] font-black text-black mt-1">GHS {totalDeposited.toFixed(2)}</div>
              </div>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                Inflow
              </span>
            </div>
            <div className="text-[11px] text-black/50 mt-3">
              Verified MoMo ledger entries across MTN & Telecel
            </div>
          </div>

          <div className="bg-white rounded-[24px] p-5 border border-black/5 shadow-sm flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-black/40">Paid for Deliveries</span>
                <div className="text-[24px] font-black text-black mt-1">GHS {totalSpent.toFixed(2)}</div>
              </div>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-black/5 text-black">
                Outflow
              </span>
            </div>
            <div className="flex items-center justify-between mt-3 pt-3 border-t border-black/5">
              <span className="text-[11px] text-black/50">{deliveryPaymentCount} orders paid via wallet</span>
              <label className="flex items-center gap-1.5 text-[11px] font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoPayEnabled}
                  onChange={e => setAutoPayEnabled(e.target.checked)}
                  className="rounded accent-black"
                />
                <span>Auto-Debit Balance</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* How it works banner */}
      <div className="bg-[#F5F5F7] rounded-[24px] p-4 md:p-6 border border-black/5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div>
            <div className="text-[14px] font-bold text-black">Williams Delivery Services Virtual Wallet</div>
            <p className="text-[12px] text-black/60 mt-0.5">
              Top up once via MTN or Telecel MoMo. Pay instantly for dispatch without waiting for SMS push approvals during checkout. 0% transaction fee.
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            setUssdStep('form')
            setShowTopupModal(true)
          }}
          className="h-10 px-4 bg-white border border-black/10 rounded-full font-bold text-[12px] text-black hover:bg-black hover:text-white transition shrink-0 uppercase tracking-wider"
        >
          Quick Top-Up
        </button>
      </div>

      {/* Transactions Ledger */}
      <div className="bg-white rounded-[32px] p-6 md:p-8 border border-black/5 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-black/5">
          <div>
            <h3 className="font-extrabold text-[20px] text-black leading-tight">Wallet Ledger & History</h3>
            <p className="text-[12px] text-black/50 mt-0.5">
              Real-time audit log of Mobile Money top-ups and delivery deductions
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Filter pills */}
            <div className="flex bg-[#F5F5F7] p-1 rounded-xl border border-black/5">
              <button
                onClick={() => setFilterType('all')}
                className={`h-8 px-3 rounded-lg text-[11px] font-bold transition uppercase tracking-wider ${
                  filterType === 'all' ? 'bg-white text-black shadow-sm' : 'text-black/50 hover:text-black'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setFilterType('momo_topup')}
                className={`h-8 px-3 rounded-lg text-[11px] font-bold transition uppercase tracking-wider ${
                  filterType === 'momo_topup' ? 'bg-white text-black shadow-sm' : 'text-black/50 hover:text-black'
                }`}
              >
                Top-ups
              </button>
              <button
                onClick={() => setFilterType('delivery_payment')}
                className={`h-8 px-3 rounded-lg text-[11px] font-bold transition uppercase tracking-wider ${
                  filterType === 'delivery_payment' ? 'bg-white text-black shadow-sm' : 'text-black/50 hover:text-black'
                }`}
              >
                Dispatches
              </button>
            </div>

            {/* Search */}
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Search reference..."
              className="h-10 bg-[#F5F5F7] border border-black/5 rounded-xl px-3 text-[12px] font-medium w-[140px] sm:w-[170px] focus:bg-white focus:border-black transition"
            />
          </div>
        </div>

        {/* Transactions List */}
        <div className="mt-4 divide-y divide-black/5">
          {filteredTransactions.length === 0 ? (
            <div className="py-12 text-center">
              <div className="text-[14px] font-bold text-black">No transactions found</div>
              <p className="text-[12px] text-black/50 mt-1 max-w-xs mx-auto">
                {searchQuery
                  ? 'No wallet activity matched your search filter.'
                  : 'Top up your wallet via MoMo to get started.'}
              </p>
            </div>
          ) : (
            filteredTransactions.map(txn => {
              const isCredit = txn.type === 'momo_topup' || txn.type === 'refund'
              return (
                <div
                  key={txn.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-[#F9F9FB] rounded-2xl px-3 -mx-3 transition"
                >
                  <div className="flex items-start gap-3.5">
                    <div
                      className={`w-10 h-10 rounded-2xl flex items-center justify-center text-[10px] font-black uppercase tracking-wider shrink-0 ${
                        isCredit ? 'bg-emerald-50 text-emerald-700' : 'bg-black/5 text-black'
                      }`}
                    >
                      {isCredit ? 'IN' : 'OUT'}
                    </div>
                    <div>
                      <div className="text-[14px] font-bold text-black leading-snug">{txn.title}</div>
                      <div className="flex flex-wrap items-center gap-2 text-[11px] text-black/40 mt-1">
                        <span>{txn.date}</span>
                        <span>•</span>
                        <span className="font-mono text-[10px] bg-black/5 px-1.5 py-0.5 rounded">
                          {txn.reference}
                        </span>
                        {txn.network && (
                          <>
                            <span>•</span>
                            <span className="font-semibold text-black/60">{txn.network}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between sm:justify-end gap-3 pl-13 sm:pl-0">
                    <div className="text-right">
                      <div
                        className={`text-[15px] font-black ${
                          isCredit ? 'text-emerald-600' : 'text-black'
                        }`}
                      >
                        {isCredit ? '+' : ''}GHS {Math.abs(txn.amount).toFixed(2)}
                      </div>
                      <span className="inline-block text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 mt-0.5">
                        {txn.status}
                      </span>
                    </div>

                    <button
                      onClick={() => setSelectedReceipt(txn)}
                      className="h-8 px-3 rounded-lg bg-black/5 hover:bg-black/10 text-[11px] font-bold text-black transition"
                    >
                      Receipt
                    </button>
                  </div>
                </div>
              )
            })
          )}
        </div>
      </div>

      {/* MoMo Top-Up Modal with realistic USSD flow */}
      {showTopupModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-[480px] rounded-[32px] p-6 md:p-8 shadow-[0_30px_90px_rgba(0,0,0,0.35)] relative overflow-hidden">
            {/* Modal Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="font-extrabold text-[18px] leading-tight">Top Up Virtual Wallet</h3>
                <p className="text-[11px] text-black/50">Instant credit via Ghana Mobile Money</p>
              </div>
              <button
                onClick={handleCloseModal}
                className="h-8 px-3 rounded-full bg-black/5 hover:bg-black/10 text-[11px] font-bold text-black/60 transition uppercase tracking-wider"
              >
                Close
              </button>
            </div>

            {/* STEP 1: Top-up Form */}
            {ussdStep === 'form' && (
              <form onSubmit={handleStartTopup} className="space-y-5">
                {/* Preset Amount Chips */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-black/50 block mb-2">
                    Select Top-Up Amount (GHS)
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    {presetAmounts.map(amt => (
                      <button
                        type="button"
                        key={amt}
                        onClick={() => setTopupAmount(amt.toString())}
                        className={`h-11 rounded-2xl font-black text-[13px] border transition ${
                          topupAmount === amt.toString()
                            ? 'bg-black text-white border-black shadow-sm'
                            : 'bg-[#F5F5F7] text-black/80 border-black/5 hover:bg-black/5'
                        }`}
                      >
                        {amt}
                      </button>
                    ))}
                  </div>

                  {/* Custom Amount Input */}
                  <div className="relative mt-2.5">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 font-extrabold text-[15px] text-black/50">
                      GHS
                    </span>
                    <input
                      type="number"
                      step="any"
                      min="5"
                      value={topupAmount}
                      onChange={e => setTopupAmount(e.target.value)}
                      placeholder="Or enter custom amount"
                      className="w-full h-[52px] bg-[#F5F5F7] border border-black/5 rounded-2xl pl-16 pr-4 text-[16px] font-bold focus:bg-white focus:border-black transition"
                      required
                    />
                  </div>
                </div>

                {/* Mobile Money Provider */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-black/50 block mb-2">
                    Mobile Money Provider
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setMomoNetwork('mtn')}
                      className={`h-14 rounded-2xl p-2 border flex flex-col items-center justify-center gap-0.5 transition ${
                        momoNetwork === 'mtn'
                          ? 'bg-[#FFC700]/15 border-[#FFC700] text-black font-extrabold ring-1 ring-[#FFC700]'
                          : 'bg-[#F5F5F7] border-black/5 text-black/70 hover:bg-black/5'
                      }`}
                    >
                      <span className="text-[12px] font-bold">MTN MoMo</span>
                      <span className="text-[9px] uppercase tracking-wider text-black/50">Direct Push</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMomoNetwork('telecel')}
                      className={`h-14 rounded-2xl p-2 border flex flex-col items-center justify-center gap-0.5 transition ${
                        momoNetwork === 'telecel'
                          ? 'bg-neutral-900 border-black text-white font-extrabold ring-1 ring-black'
                          : 'bg-[#F5F5F7] border-black/5 text-black/70 hover:bg-black/5'
                      }`}
                    >
                      <span className="text-[12px] font-bold">Telecel Cash</span>
                      <span className="text-[9px] uppercase tracking-wider text-neutral-400">Vodafone</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMomoNetwork('airteltigo')}
                      className={`h-14 rounded-2xl p-2 border flex flex-col items-center justify-center gap-0.5 transition ${
                        momoNetwork === 'airteltigo'
                          ? 'bg-neutral-900 border-black text-white font-extrabold ring-1 ring-black'
                          : 'bg-[#F5F5F7] border-black/5 text-black/70 hover:bg-black/5'
                      }`}
                    >
                      <span className="text-[12px] font-bold">AT Money</span>
                      <span className="text-[9px] uppercase tracking-wider text-neutral-400">AirtelTigo</span>
                    </button>
                  </div>
                </div>

                {/* MoMo Phone Number */}
                <div>
                  <label className="text-[11px] font-bold uppercase tracking-wider text-black/50 block mb-1.5">
                    MoMo Phone Number
                  </label>
                  <div className="relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[13px] font-bold text-black">
                      +233
                    </span>
                    <input
                      type="tel"
                      value={momoPhone}
                      onChange={e => setMomoPhone(e.target.value)}
                      placeholder="0244 123 456"
                      className="w-full h-[52px] bg-[#F5F5F7] border border-black/5 rounded-2xl pl-16 pr-4 text-[14px] font-medium focus:bg-white focus:border-black transition"
                      required
                    />
                  </div>
                  <p className="text-[10px] text-black/40 mt-1">
                    A secure USSD authorization prompt will be pushed to this number.
                  </p>
                </div>

                {/* Fee Breakdown */}
                <div className="bg-[#F5F5F7] rounded-2xl p-3.5 space-y-1.5 text-[12px]">
                  <div className="flex justify-between text-black/60">
                    <span>Deposit Amount:</span>
                    <span className="font-bold text-black">GHS {parseFloat(topupAmount || '0').toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-black/60">
                    <span>Transfer & E-Levy Fee:</span>
                    <span className="font-bold text-emerald-600">GHS 0.00 (WDS Covered)</span>
                  </div>
                  <div className="h-[1px] bg-black/5 my-1" />
                  <div className="flex justify-between font-extrabold text-black text-[13px]">
                    <span>Total MoMo Debit:</span>
                    <span>GHS {parseFloat(topupAmount || '0').toFixed(2)}</span>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full h-[54px] bg-[#FFC700] hover:bg-[#ffcf22] text-black rounded-full font-extrabold text-[14px] flex items-center justify-center gap-2 active:scale-[0.98] transition shadow-md"
                >
                  <span>Authorize MoMo Top-Up</span>
                  <span>→</span>
                </button>
              </form>
            )}

            {/* STEP 2: Realistic Ghana USSD Prompt Simulator */}
            {ussdStep === 'prompt' && (
              <div className="space-y-5">
                <div className="bg-[#1C1C1E] text-white rounded-[24px] p-5 shadow-inner border border-white/10">
                  <div className="flex items-center justify-between text-[11px] text-white/50 border-b border-white/10 pb-2 mb-3">
                    <span className="font-mono">GhIPSS Mobile Money USSD</span>
                    <span className="bg-[#FFC700] text-black px-2 py-0.5 rounded font-bold">
                      {momoNetwork.toUpperCase()}
                    </span>
                  </div>

                  <p className="text-[13px] font-medium leading-relaxed">
                    Authorize payment of <span className="text-[#FFC700] font-bold">GHS {parseFloat(topupAmount).toFixed(2)}</span> to <span className="font-bold">Williams Delivery Services (WDS)</span>?
                  </p>
                  <p className="text-[11px] text-white/60 mt-1">
                    Phone: +233 {momoPhone} • Ref: WDS-TOP-{Math.floor(1000 + Math.random() * 9000)}
                  </p>

                  <div className="mt-4 pt-3 border-t border-white/10">
                    <label className="text-[11px] font-bold uppercase tracking-wider text-white/60 block mb-1.5">
                      Enter Mobile Money PIN to Authorize:
                    </label>
                    <input
                      type="password"
                      maxLength={4}
                      value={momoPin}
                      onChange={e => setMomoPin(e.target.value.replace(/\D/g, ''))}
                      placeholder="••••"
                      autoFocus
                      className="w-full h-[48px] bg-white/10 border border-white/20 rounded-xl px-4 text-center font-mono text-[22px] tracking-[0.3em] text-white focus:bg-white/20 focus:border-[#FFC700] transition"
                    />
                    <div className="flex justify-between items-center mt-2 text-[10px] text-white/40">
                      <span>Encrypted GhIPSS TLS 1.3</span>
                      <button
                        type="button"
                        onClick={() => setMomoPin('1234')}
                        className="text-[#FFC700] font-bold underline"
                      >
                        Fill Demo PIN (1234)
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setUssdStep('form')}
                    className="flex-1 h-[50px] bg-[#F5F5F7] hover:bg-black/5 text-black font-bold text-[13px] rounded-full transition"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmUssd}
                    disabled={isProcessingUssd}
                    className="flex-[2] h-[50px] bg-[#FFC700] hover:bg-[#ffcf22] text-black font-extrabold text-[13px] rounded-full flex items-center justify-center active:scale-[0.98] transition shadow-md disabled:opacity-60 uppercase tracking-wider"
                  >
                    {isProcessingUssd ? (
                      <>
                        <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin mr-2" />
                        <span>Verifying with MoMo...</span>
                      </>
                    ) : (
                      <span>Approve & Credit Wallet</span>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Success Confirmation */}
            {ussdStep === 'success' && (
              <div className="text-center py-4 space-y-4">
                <div className="w-12 h-12 bg-emerald-100 text-emerald-800 font-black rounded-full flex items-center justify-center text-[15px] mx-auto uppercase tracking-wider">
                  OK
                </div>
                <div>
                  <h4 className="font-extrabold text-[20px] text-black">Wallet Credited Successfully!</h4>
                  <p className="text-[13px] text-black/60 mt-1">
                    GHS {parseFloat(topupAmount).toFixed(2)} added from your {momoNetwork === 'mtn' ? 'MTN MoMo' : momoNetwork === 'telecel' ? 'Telecel Cash' : 'AT Money'} account.
                  </p>
                </div>

                <div className="bg-[#F5F5F7] rounded-2xl p-4 text-left space-y-2 text-[12px]">
                  <div className="flex justify-between">
                    <span className="text-black/50">New Wallet Balance:</span>
                    <span className="font-black text-black">GHS {balance.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-black/50">Payment Reference:</span>
                    <span className="font-mono font-bold text-black">
                      MM-TOP-{Math.floor(10000 + Math.random() * 90000)}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-black/50">Settlement Speed:</span>
                    <span className="font-semibold text-emerald-600">Instant (Real-time)</span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="w-full h-[52px] bg-black text-white rounded-full font-bold text-[14px] hover:bg-black/90 transition uppercase tracking-wider"
                >
                  Done
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Transaction Receipt Modal */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-[420px] rounded-[32px] p-6 md:p-8 shadow-[0_30px_90px_rgba(0,0,0,0.3)] relative">
            <button
              onClick={() => setSelectedReceipt(null)}
              className="absolute top-6 right-6 h-8 px-3 rounded-full bg-black/5 hover:bg-black/10 text-[11px] font-bold text-black/60 uppercase tracking-wider"
            >
              Close
            </button>

            <div className="text-center pb-4 border-b border-black/5">
              <div className="w-10 h-10 rounded-2xl bg-black text-[#FFC700] flex items-center justify-center font-extrabold text-[18px] mx-auto mb-2">
                W
              </div>
              <div className="font-black text-[16px]">Williams Delivery Services</div>
              <div className="text-[11px] text-black/40 uppercase tracking-widest mt-0.5">
                Official Transaction Receipt
              </div>
            </div>

            <div className="py-4 text-center">
              <span className="text-[11px] uppercase font-bold text-black/40">Amount</span>
              <div
                className={`text-[32px] font-black leading-tight mt-0.5 ${
                  selectedReceipt.type === 'momo_topup' ? 'text-emerald-600' : 'text-black'
                }`}
              >
                {selectedReceipt.type === 'momo_topup' ? '+' : ''}GHS{' '}
                {Math.abs(selectedReceipt.amount).toFixed(2)}
              </div>
              <div className="text-[12px] font-bold text-black/70 mt-1">{selectedReceipt.title}</div>
            </div>

            <div className="bg-[#F5F5F7] rounded-2xl p-4 space-y-2 text-[12px]">
              <div className="flex justify-between">
                <span className="text-black/50">Status:</span>
                <span className="font-bold text-emerald-600 uppercase text-[11px]">
                  {selectedReceipt.status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/50">Transaction Ref:</span>
                <span className="font-mono font-bold text-black">{selectedReceipt.reference}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-black/50">Date & Time:</span>
                <span className="font-semibold text-black">{selectedReceipt.date}</span>
              </div>
              {selectedReceipt.network && (
                <div className="flex justify-between">
                  <span className="text-black/50">Payment Channel:</span>
                  <span className="font-bold text-black">{selectedReceipt.network}</span>
                </div>
              )}
              {selectedReceipt.orderId && (
                <div className="flex justify-between">
                  <span className="text-black/50">Order Number:</span>
                  <span className="font-bold text-black">#{selectedReceipt.orderId}</span>
                </div>
              )}
            </div>

            <div className="mt-6 flex gap-2">
              <button
                onClick={() => setSelectedReceipt(null)}
                className="w-full h-[48px] bg-black text-white font-bold rounded-full text-[13px] hover:bg-black/90 transition"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
