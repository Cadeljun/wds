'use client'

import { useState, useEffect, lazy, Suspense } from 'react'
import { useRouter } from 'next/navigation'
import dynamic from 'next/dynamic'
import { ErrorBoundary } from '@/components/ErrorBoundary'
import { RouteLoadingFallback } from '@/components/RouteLoadingFallback'
import LandingView from '@/components/views/LandingView'
import { loginSchema, signupSchema, getFieldErrors } from '@/lib/validation'
import { sanitizeName, sanitizeGhanaPhone, sanitizeEmail } from '@/lib/sanitize'
import { useRealtimeData } from '@/lib/use-realtime'

// ONLY landing is eager - small, always needed
// Everything else is lazy - heavy, not needed on first paint
const CustomerView = lazy(() => import('@/components/views/CustomerView'))
const RiderView = lazy(() => import('@/components/views/RiderView'))
const AdminView = lazy(() => import('@/components/views/AdminView'))

type View = 'landing' | 'customer' | 'rider' | 'admin'

function withSuspense(Component: React.LazyExoticComponent<React.ComponentType<any>>, fallbackLabel: string) {
  return (props: any) => (
    <ErrorBoundary>
      <Suspense fallback={<RouteLoadingFallback label={fallbackLabel} />}>
        <Component {...props} />
      </Suspense>
    </ErrorBoundary>
  )
}

const LazyCustomer = withSuspense(CustomerView, 'Loading customer dashboard...')
const LazyRider = withSuspense(RiderView, 'Loading rider jobs...')
const LazyAdmin = withSuspense(AdminView, 'Loading admin dashboard...')

export default function OptimizedHome() {
  const router = useRouter()
  const [currentUser, setCurrentUser] = useState<any>(null)
  const [view, setView] = useState<View>('landing')
  const [localOrders, setLocalOrders] = useState<any[]>([])
  const [users, setUsers] = useState<any[]>([])
  const [showAuth, setShowAuth] = useState(false)
  const [authTab, setAuthTab] = useState<'login' | 'signup'>('login')

  // Real-time server-authoritative live stream
  const { allOrders: liveOrders, riders: liveRiders, isConnected, lastEventAt } = useRealtimeData(
    currentUser?.role,
    currentUser?.id
  )

  // Merge live server-streamed orders with any offline/local orders
  const orders = liveOrders.length > 0 ? liveOrders : localOrders

  // Auth forms with Zod validation
  const [loginMethod, setLoginMethod] = useState<'phone' | 'email'>('phone')
  const [loginPhone, setLoginPhone] = useState('')
  const [loginEmail, setLoginEmail] = useState('')
  const [loginPass, setLoginPass] = useState('')
  const [loginErrors, setLoginErrors] = useState<Record<string, string>>({})
  const [signupName, setSignupName] = useState('')
  const [signupEmail, setSignupEmail] = useState('')
  const [signupPhone, setSignupPhone] = useState('')
  const [signupRole, setSignupRole] = useState<'customer' | 'rider'>('customer')
  const [signupPass, setSignupPass] = useState('')
  const [signupErrors, setSignupErrors] = useState<Record<string, string>>({})

  const [price] = useState({ total: 42, km: 8.4, mins: 22 })

  useEffect(() => {
    const savedUser = localStorage.getItem('wds_session_v2')
    const savedOrders = localStorage.getItem('wds_orders_v2')
    const savedUsers = localStorage.getItem('wds_users_v2')
    if (savedUser) {
      const u = JSON.parse(savedUser)
      setCurrentUser(u)
      setView(u.role === 'admin' ? 'admin' : u.role === 'rider' ? 'rider' : 'customer')
    }
    if (savedOrders) setLocalOrders(JSON.parse(savedOrders))
    else setLocalOrders([
      { id: 'WDS-91', pickup: 'Madina Market', dropoff: 'Legon Campus', type: 'Food', price: 'GHS 35', status: 'Delivered', rider: 'Ama K.', date: 'Today 10:42am' },
      { id: 'WDS-90', pickup: 'Kaneshie Market', dropoff: 'Dansoman', type: 'Grocery', price: 'GHS 52', status: 'On the way', rider: 'Kwame A.', date: 'Today 9:18am' },
    ])
    if (savedUsers) setUsers(JSON.parse(savedUsers))
  }, [])

  function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setLoginErrors({})

    // Zod validation with loginMethod
    const result = loginSchema.safeParse({
      loginType: loginMethod,
      phone: loginMethod === 'phone' ? loginPhone : undefined,
      email: loginMethod === 'email' ? loginEmail : undefined,
      password: loginPass,
    })
    if (!result.success) {
      setLoginErrors(getFieldErrors(result.error))
      return
    }

    const allUsers = JSON.parse(localStorage.getItem('wds_users_v2') || '[]')
    const cleanPhone = result.data.phone ? sanitizeGhanaPhone(result.data.phone) : ''
    const cleanEmail = result.data.email ? sanitizeEmail(result.data.email) : ''

    const user = allUsers.find((u: any) => {
      if (loginMethod === 'email') {
        return u.email?.toLowerCase() === cleanEmail.toLowerCase() && u.password === result.data.password
      }
      return u.phone?.replace(/\s+/g, '') === cleanPhone.replace(/\s+/g, '') && u.password === result.data.password
    })

    if (!user) {
      // Check demo accounts
      const demoUsers = [
        { phone: '0244123456', email: 'ama.mensah@gmail.com', password: '123456', role: 'customer', name: 'Ama Mensah' },
        { phone: '0244987654', email: 'kwame.asare@gmail.com', password: '123456', role: 'rider', name: 'Kwame Asare' },
        { phone: '0244000000', email: 'admin@wds.com.gh', password: 'admin123', role: 'admin', name: 'Williams Admin' },
      ]
      const demo = demoUsers.find(u => {
        if (loginMethod === 'email') return u.email.toLowerCase() === cleanEmail.toLowerCase() && u.password === result.data.password
        return u.phone === cleanPhone && u.password === result.data.password
      })

      if (demo) {
        const demoUser = { ...demo, id: 'u_' + Date.now() }
        localStorage.setItem('wds_session_v2', JSON.stringify(demoUser))
        setCurrentUser(demoUser)
        setView(demoUser.role === 'admin' ? 'admin' : demoUser.role === 'rider' ? 'rider' : 'customer')
        setShowAuth(false)
        setLoginErrors({})
        return
      }

      alert('Invalid credentials. Demo: 0244123456 / ama.mensah@gmail.com / 123456 (customer), 0244987654 / kwame.asare@gmail.com / 123456 (rider), 0244000000 / admin123 (admin)')
      return
    }
    localStorage.setItem('wds_session_v2', JSON.stringify(user))
    setCurrentUser(user)
    setView(user.role === 'admin' ? 'admin' : user.role === 'rider' ? 'rider' : 'customer')
    setShowAuth(false)
    setLoginErrors({})
  }

  function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    setSignupErrors({})

    // Zod validation with Ghana phone + password strength + email
    const result = signupSchema.safeParse({
      name: signupName,
      email: signupEmail,
      phone: signupPhone,
      password: signupPass,
      role: signupRole,
      vehicle_type: 'motor',
      license_plate: '',
      agreedToTerms: true,
    })

    if (!result.success) {
      setSignupErrors(getFieldErrors(result.error))
      return
    }

    const allUsers = JSON.parse(localStorage.getItem('wds_users_v2') || '[]')
    const phone = sanitizeGhanaPhone(result.data.phone)
    const email = sanitizeEmail(result.data.email)
    if (allUsers.find((u: any) => u.phone === phone || (email && u.email?.toLowerCase() === email.toLowerCase()))) {
      alert('Phone or email already registered')
      return
    }

    const newUser = {
      id: 'u_' + Date.now(),
      name: sanitizeName(result.data.name),
      email,
      phone,
      role: result.data.role,
      vehicle: result.data.role === 'rider' ? 'motor' : '',
      plate: '',
      password: result.data.password,
      rating: 5, earnings: 0, online: result.data.role === 'rider',
      createdAt: new Date().toISOString(),
    }
    allUsers.push(newUser)
    localStorage.setItem('wds_users_v2', JSON.stringify(allUsers))
    localStorage.setItem('wds_session_v2', JSON.stringify(newUser))
    setCurrentUser(newUser)
    setView(newUser.role === 'rider' ? 'rider' : 'customer')
    setShowAuth(false)
    setSignupErrors({})
  }

  function logout() {
    localStorage.removeItem('wds_session_v2')
    setCurrentUser(null)
    setView('landing')
  }

  async function placeOrder(data: any) {
    if (!currentUser) { setShowAuth(true); return }
    const orderId = 'WDS-' + (100 + orders.length)
    const newOrder = {
      id: orderId,
      ...data,
      customerId: currentUser.id,
      customerName: currentUser.name,
      status: 'pending',
      date: 'Just now',
    }

    let finalOrderId = orderId

    // Persist to database via API
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer demo-token-${currentUser.id}-${currentUser.role}`,
        },
        body: JSON.stringify({
          pickup_address: data.pickup || 'East Legon, American House',
          pickup_lat: 5.6365,
          pickup_lng: -0.1645,
          dropoff_address: data.dropoff || 'Osu, Oxford Street',
          dropoff_lat: 5.5560,
          dropoff_lng: -0.1760,
          package_type: data.type || 'parcel',
          description: data.description || 'Fragile package',
          recipient_name: data.recipientName || 'Recipient',
          recipient_phone: data.recipientPhone || '0244123456',
          payment_method: data.paymentMethod || 'momo_mtn',
          express: false,
        }),
      })
      const result = await res.json()
      if (result?.order?.id) {
        finalOrderId = result.order.id
        newOrder.id = result.order.id
      }
    } catch (err) {
      console.error('Failed to post order to server:', err)
    }

    // Save locally
    const updated = [newOrder, ...localOrders]
    setLocalOrders(updated)
    localStorage.setItem('wds_orders_v2', JSON.stringify(updated))

    // Prompt user to track in real-time
    router.push(`/order/${finalOrderId}`)
  }

  async function handleAcceptJob(job: any) {
    try {
      await fetch(`/api/orders/${job.id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer demo-token-${currentUser.id}-${currentUser.role}`,
        },
        body: JSON.stringify({
          status: 'accepted',
          riderId: currentUser.id,
          riderName: currentUser.name,
          etaMinutes: 15,
        }),
      })
      alert(`Accepted delivery ${job.id}! Updated live dispatch network.`)
    } catch {
      alert(`Accepted ${job.id} locally.`)
    }
  }

  async function handleUpdateOrderStatus(orderId: string, nextStatus: string) {
    try {
      await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer demo-token-${currentUser.id}-${currentUser.role}`,
        },
        body: JSON.stringify({
          status: nextStatus,
        }),
      })
    } catch (err) {
      console.error('Failed to update status:', err)
    }
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-xl border-b border-black/5">
        <div className="max-w-[1440px] mx-auto px-4 md:px-8 h-[64px] flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView(currentUser ? (currentUser.role === 'admin' ? 'admin' : currentUser.role === 'rider' ? 'rider' : 'customer') : 'landing')}>
            <div className="w-9 h-9 bg-black rounded-xl flex items-center justify-center text-[#FFC700] font-extrabold text-[18px]">W</div>
            <div><div className="font-extrabold text-[16px] leading-none tracking-tight">WDS</div><div className="text-[10px] font-semibold tracking-[0.15em] text-black/60 uppercase -mt-0.5">Williams Delivery</div></div>
          </div>
          <div className="flex items-center gap-2">
            {!currentUser ? (
              <>
                <button onClick={() => { setAuthTab('login'); setShowAuth(true) }} className="h-9 px-4 rounded-full text-[13px] font-semibold text-black/70 hover:bg-black/5">Log in</button>
                <button onClick={() => { setAuthTab('signup'); setShowAuth(true) }} className="h-9 px-5 bg-black text-white rounded-full text-[13px] font-bold">Sign up</button>
              </>
            ) : (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-3 pl-2">
                  <div className="hidden md:block text-right">
                    <div className="text-[13px] font-bold leading-none text-black">{currentUser.name}</div>
                    <div className="text-[11px] text-black/50 capitalize font-medium mt-0.5">{currentUser.role} Account • Ghana</div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-black text-[#FFC700] flex items-center justify-center font-bold text-[13px] border border-black/10">
                    {currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}
                  </div>
                  <button 
                    onClick={logout} 
                    className="h-8 px-3 rounded-full bg-black/5 hover:bg-black/10 text-[12px] font-semibold text-black/70 hover:text-black transition flex items-center gap-1.5"
                    title="Sign out of your account"
                  >
                    <span>Sign out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </header>

      {view === 'landing' && (
        <LandingView 
          onSignup={() => { setAuthTab('signup'); setShowAuth(true) }} 
          onLogin={() => { setAuthTab('login'); setShowAuth(true) }}
          pickup="East Legon, American House"
          dropoff="Osu, Oxford Street"
          price={price}
        />
      )}

      {view === 'customer' && (
        <LazyCustomer 
          currentUser={currentUser} 
          orders={orders} 
          onPlaceOrder={placeOrder} 
          onTrack={(o: any) => router.push(`/order/${o.id}`)} 
        />
      )}

      {view === 'rider' && (
        <LazyRider 
          currentUser={currentUser} 
          orders={orders}
          onAcceptJob={handleAcceptJob}
          onUpdateStatus={handleUpdateOrderStatus}
        />
      )}

      {view === 'admin' && (
        <LazyAdmin 
          orders={orders} 
          users={users} 
          onExport={() => {
            const csv = ['OrderID,Customer,Pickup,Dropoff,Price,Status', ...orders.map((o: any) => `${o.id},${o.customerName||''},${o.pickup},${o.dropoff},${o.price},${o.status}`)].join('\n')
            const blob = new Blob([csv], { type: 'text/csv' })
            const url = URL.createObjectURL(blob)
            const a = document.createElement('a')
            a.href = url; a.download = 'wds-orders.csv'; a.click()
          }} 
        />
      )}

      {showAuth && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowAuth(false)}></div>
          <div className="relative bg-white w-full max-w-[440px] rounded-[32px] p-8 shadow-[0_30px_80px_rgba(0,0,0,0.3)]">
            <div className="flex justify-between mb-6"><div className="flex items-center gap-2"><div className="w-8 h-8 bg-black text-[#FFC700] rounded-xl flex items-center justify-center font-bold">W</div><span className="font-bold">WDS • Secured Auth</span></div><button onClick={() => setShowAuth(false)} className="w-8 h-8 bg-black/5 rounded-full">×</button></div>
            <h2 className="font-extrabold text-[24px]">{authTab === 'login' ? 'Welcome back' : 'Join WDS'}</h2>
            <p className="text-[12px] text-black/60 mt-1">Ghana phone & email verification • Zod • XSS protection</p>
            <div className="flex bg-[#F5F5F7] rounded-full p-1 mt-4">
              <button onClick={() => setAuthTab('login')} className={`flex-1 h-9 rounded-full text-[13px] font-bold ${authTab === 'login' ? 'bg-white shadow' : 'text-black/60'}`}>Log in</button>
              <button onClick={() => setAuthTab('signup')} className={`flex-1 h-9 rounded-full text-[13px] font-bold ${authTab === 'signup' ? 'bg-white shadow' : 'text-black/60'}`}>Sign up</button>
            </div>
            {authTab === 'login' ? (
              <form onSubmit={handleLogin} className="mt-6 space-y-3">
                <div className="flex bg-[#F5F5F7] rounded-xl p-1 gap-1 border border-black/5">
                  <button
                    type="button"
                    onClick={() => {
                      setLoginMethod('phone')
                      setLoginErrors({})
                    }}
                    className={`flex-1 h-8 rounded-lg text-[12px] font-bold transition uppercase tracking-wider ${loginMethod === 'phone' ? 'bg-white shadow-sm text-black' : 'text-black/50'}`}
                  >
                    Phone
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setLoginMethod('email')
                      setLoginErrors({})
                    }}
                    className={`flex-1 h-8 rounded-lg text-[12px] font-bold transition uppercase tracking-wider ${loginMethod === 'email' ? 'bg-white shadow-sm text-black' : 'text-black/50'}`}
                  >
                    Email
                  </button>
                </div>

                {loginMethod === 'phone' ? (
                  <div>
                    <input value={loginPhone} onChange={e => setLoginPhone(e.target.value)} placeholder="Phone 0244 123 456 (Ghana)" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${loginErrors.phone ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                    {loginErrors.phone && <p className="text-red-500 text-[11px] mt-1 font-semibold">{loginErrors.phone}</p>}
                  </div>
                ) : (
                  <div>
                    <input value={loginEmail} onChange={e => setLoginEmail(e.target.value)} type="email" placeholder="Email (e.g. ama.mensah@gmail.com)" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${loginErrors.email ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                    {loginErrors.email && <p className="text-red-500 text-[11px] mt-1 font-semibold">{loginErrors.email}</p>}
                  </div>
                )}

                <div>
                  <input value={loginPass} onChange={e => setLoginPass(e.target.value)} type="password" placeholder="Password" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${loginErrors.password ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                  {loginErrors.password && <p className="text-red-500 text-[11px] mt-1 font-semibold">{loginErrors.password}</p>}
                </div>
                <button type="submit" className="w-full h-[52px] bg-black text-white rounded-full font-bold uppercase tracking-wider">Log in</button>
                <div className="text-[11px] text-black/50 text-center">Demo accounts: Customer (0244123456 / ama.mensah@gmail.com) • Rider (0244987654 / kwame.asare@gmail.com) • Pass: 123456</div>
              </form>
            ) : (
              <form onSubmit={handleSignup} className="mt-6 space-y-3">
                <div>
                  <input value={signupName} onChange={e => setSignupName(e.target.value)} placeholder="Full Name" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${signupErrors.name ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                  {signupErrors.name && <p className="text-red-500 text-[11px] mt-1 font-semibold">{signupErrors.name}</p>}
                </div>
                <div>
                  <input value={signupEmail} onChange={e => setSignupEmail(e.target.value)} type="email" placeholder="Email Address (e.g. ama.mensah@gmail.com)" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${signupErrors.email ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                  {signupErrors.email && <p className="text-red-500 text-[11px] mt-1 font-semibold">{signupErrors.email}</p>}
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <select value={signupRole} onChange={e => setSignupRole(e.target.value as any)} className="h-[48px] bg-[#F5F5F7] rounded-2xl px-3 text-[14px]"><option value="customer">Customer</option><option value="rider">Rider</option></select>
                  <div>
                    <input value={signupPhone} onChange={e => setSignupPhone(e.target.value)} placeholder="Phone 0244..." className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${signupErrors.phone ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required />
                    {signupErrors.phone && <p className="text-red-500 text-[11px] mt-1 font-semibold">{signupErrors.phone}</p>}
                  </div>
                </div>
                <div>
                  <input value={signupPass} onChange={e => setSignupPass(e.target.value)} type="password" placeholder="Password: letter + number, min 6" className={`w-full h-[48px] bg-[#F5F5F7] border rounded-2xl px-4 text-[14px] ${signupErrors.password ? 'border-red-500 bg-red-50' : 'border-black/5'}`} required minLength={6} />
                  {signupErrors.password && <p className="text-red-500 text-[11px] mt-1 font-semibold">{signupErrors.password}</p>}
                </div>
                <button type="submit" className="w-full h-[52px] bg-[#FFC700] text-black rounded-full font-extrabold uppercase tracking-wider">Create Account</button>
                <div className="text-[11px] text-black/50 text-center">Ghana mobile & email verification with secure OTP verification</div>
              </form>
            )}
          </div>
        </div>
      )}

      <footer className="mt-12 border-t bg-white">
        <div className="max-w-[1440px] mx-auto px-4 md:px-8 py-8">
          <div className="flex flex-wrap justify-between gap-4 text-[12px] text-black/50">
            <div className="flex items-center gap-2"><div className="w-6 h-6 bg-black text-[#FFC700] rounded-lg flex items-center justify-center font-bold">W</div><span className="font-bold text-black">Williams Delivery Service</span><span>• Accra, Ghana</span></div>
            <div className="flex flex-wrap gap-4">
              <a href="/about" className="hover:text-black transition">About</a>
              <a href="/pricing" className="hover:text-black transition">Pricing</a>
              <a href="/compare" className="hover:text-black transition">Compare</a>
              <a href="/contact" className="hover:text-black transition">Contact</a>
              <a href="/privacy" className="hover:text-black transition">Privacy</a>
              <a href="/sitemap.xml" className="hover:text-black transition">Sitemap</a>
            </div>
          </div>
          <div className="mt-4 flex flex-wrap justify-between items-center gap-2 text-[12px] text-black/60">
            <span>© {new Date().getFullYear()} Williams Delivery Service Ltd. Reliable on-demand courier & logistics across Greater Accra.</span>
            <span className="px-3 py-1 bg-green-50 text-green-700 rounded-full border border-green-200 text-[11px] font-bold">Verified & Active</span>
          </div>
        </div>
      </footer>
    </div>
  )
}
