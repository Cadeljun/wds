'use client'

import { useState } from 'react'

export interface RiderTransaction {
  id: string
  orderId?: string
  type: 'delivery_earning' | 'tip' | 'bonus' | 'payout_momo' | 'payout_bank'
  title: string
  amount: number
  date: string
  status: 'completed' | 'pending' | 'processing'
  momoNetwork?: string
  grossAmount?: number
  commissionDeducted?: number
}

interface RiderWalletProps {
  currentUser: any
  orders?: any[]
}

export default function RiderWallet({ currentUser, orders = [] }: RiderWalletProps) {
  // Payout request modal/state
  const [showPayoutModal, setShowPayoutModal] = useState(false)
  const [payoutAmount, setPayoutAmount] = useState('')
  const [payoutNetwork, setPayoutNetwork] = useState('MTN Mobile Money')
  const [payoutPhone, setPayoutPhone] = useState(currentUser?.phone || '0244987654')
  const [filterPeriod, setFilterPeriod] = useState<'today' | 'week' | 'month'>('today')

  // Derive transactions from completed orders and default historical transactions
  const myCompletedOrders = orders.filter(
    (o: any) =>
      (o.riderId === currentUser?.id || o.rider === currentUser?.name) &&
      o.status === 'delivered'
  )

  // Seed baseline transactions
  const [transactions, setTransactions] = useState<RiderTransaction[]>([
    {
      id: 'TXN-7041',
      orderId: 'WDS-91',
      type: 'delivery_earning',
      title: 'Delivery Fare #WDS-91 (Madina → Legon)',
      amount: 28.00,
      grossAmount: 35.00,
      commissionDeducted: 7.00,
      date: 'Today 11:15 AM',
      status: 'completed',
    },
    {
      id: 'TXN-7040',
      type: 'tip',
      orderId: 'WDS-91',
      title: 'Customer Tip (Madina → Legon)',
      amount: 10.00,
      grossAmount: 10.00,
      commissionDeducted: 0.00,
      date: 'Today 11:16 AM',
      status: 'completed',
    },
    {
      id: 'TXN-7038',
      orderId: 'WDS-86',
      type: 'delivery_earning',
      title: 'Delivery Fare #WDS-86 (East Legon → Airport)',
      amount: 32.00,
      grossAmount: 40.00,
      commissionDeducted: 8.00,
      date: 'Today 09:30 AM',
      status: 'completed',
    },
    {
      id: 'TXN-7035',
      type: 'bonus',
      title: 'Peak Hour Fuel Incentive (Morning Rush)',
      amount: 15.00,
      grossAmount: 15.00,
      commissionDeducted: 0.00,
      date: 'Today 08:45 AM',
      status: 'completed',
    },
    {
      id: 'TXN-6992',
      type: 'payout_momo',
      title: 'Instant Cashout to MTN MoMo (0244***654)',
      amount: -150.00,
      date: 'Yesterday 06:20 PM',
      status: 'completed',
      momoNetwork: 'MTN MoMo',
    },
    {
      id: 'TXN-6940',
      orderId: 'WDS-81',
      type: 'delivery_earning',
      title: 'Delivery Fare #WDS-81 (Adabraka → Tema)',
      amount: 64.00,
      grossAmount: 80.00,
      commissionDeducted: 16.00,
      date: 'Yesterday 03:10 PM',
      status: 'completed',
    },
  ])

  // Compute live financial totals
  // Base available balance calculation
  const completedGross = transactions
    .filter(t => t.type !== 'payout_momo' && t.type !== 'payout_bank' && t.status === 'completed')
    .reduce((sum, t) => sum + (t.grossAmount || t.amount), 0)

  const commissionRate = 0.20 // 20% platform fee, 80% rider keep

  // Daily totals
  const todayEarningsTxns = transactions.filter(
    t => t.date.startsWith('Today') && t.type !== 'payout_momo' && t.type !== 'payout_bank'
  )

  const todayGross = todayEarningsTxns.reduce((sum, t) => sum + (t.grossAmount || t.amount), 0)
  const todayCommission = todayEarningsTxns.reduce((sum, t) => sum + (t.commissionDeducted || 0), 0)
  const todayNet = todayEarningsTxns.reduce((sum, t) => sum + t.amount, 0)

  // Wallet available balance
  const totalWithdrawn = Math.abs(
    transactions
      .filter(t => (t.type === 'payout_momo' || t.type === 'payout_bank') && t.status === 'completed')
      .reduce((sum, t) => sum + t.amount, 0)
  )

  const totalEarnedNet = transactions
    .filter(t => t.type !== 'payout_momo' && t.type !== 'payout_bank' && t.status === 'completed')
    .reduce((sum, t) => sum + t.amount, 0)

  const availableBalance = Math.max(0, totalEarnedNet - totalWithdrawn)

  // Pending payouts
  const pendingPayouts = transactions.filter(
    t => (t.type === 'payout_momo' || t.type === 'payout_bank') && t.status === 'pending'
  )
  const pendingPayoutTotal = Math.abs(pendingPayouts.reduce((sum, t) => sum + t.amount, 0))

  const handleRequestPayout = (e: React.FormEvent) => {
    e.preventDefault()
    const amountNum = parseFloat(payoutAmount)
    if (isNaN(amountNum) || amountNum <= 0) {
      alert('Please enter a valid amount')
      return
    }
    if (amountNum > availableBalance) {
      alert(`Requested amount (GHS ${amountNum}) exceeds available balance (GHS ${availableBalance.toFixed(2)})`)
      return
    }

    const newPayout: RiderTransaction = {
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      type: 'payout_momo',
      title: `Mobile Money Cashout to ${payoutPhone} (${payoutNetwork})`,
      amount: -amountNum,
      date: 'Just now',
      status: 'pending',
      momoNetwork: payoutNetwork,
    }

    setTransactions([newPayout, ...transactions])
    setPayoutAmount('')
    setShowPayoutModal(false)
  }

  return (
    <div className="space-y-6" id="rider-wallet-section">
      {/* Wallet Metric Cards */}
      <div className="grid sm:grid-cols-3 gap-4">
        {/* Available Balance */}
        <div className="bg-black text-white rounded-[24px] p-6 flex flex-col justify-between shadow-[0_12px_32px_rgba(0,0,0,0.15)] relative overflow-hidden">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-white/50 font-bold">Available Balance</span>
              <div className="text-[32px] font-extrabold mt-1">GHS {availableBalance.toFixed(2)}</div>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-white/10 flex items-center justify-center text-[18px]">
              💳
            </div>
          </div>
          <div className="mt-6 flex items-center justify-between pt-4 border-t border-white/10">
            <span className="text-[12px] text-white/60">Instant MoMo Payout</span>
            <button
              id="rider-payout-button"
              onClick={() => setShowPayoutModal(true)}
              disabled={availableBalance < 5}
              className="px-4 py-2 bg-[#FFC700] text-black font-bold text-[12px] rounded-full hover:bg-[#e6b400] transition disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Request Payout
            </button>
          </div>
        </div>

        {/* Pending Payouts */}
        <div className="bg-white rounded-[24px] p-6 border border-black/5 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-black/50 font-bold">Pending Payouts</span>
              <div className="text-[28px] font-extrabold mt-1 text-amber-600">
                GHS {pendingPayoutTotal.toFixed(2)}
              </div>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center text-[18px]">
              ⏳
            </div>
          </div>
          <div className="mt-4 text-[12px] text-black/60 flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></span>
            <span>{pendingPayouts.length} payout{pendingPayouts.length === 1 ? '' : 's'} processing to MoMo</span>
          </div>
        </div>

        {/* Daily Net Take-home */}
        <div className="bg-white rounded-[24px] p-6 border border-black/5 flex flex-col justify-between shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[11px] uppercase tracking-wider text-black/50 font-bold">Today's Net Take-Home</span>
              <div className="text-[28px] font-extrabold mt-1 text-green-700">
                GHS {todayNet.toFixed(2)}
              </div>
            </div>
            <div className="w-10 h-10 rounded-2xl bg-green-50 text-green-700 flex items-center justify-center text-[18px]">
              📈
            </div>
          </div>
          <div className="mt-4 text-[12px] text-black/60 flex items-center justify-between">
            <span>80% rider share (20% WDS fee)</span>
            <span className="font-bold text-black">{todayEarningsTxns.length} trips</span>
          </div>
        </div>
      </div>

      {/* Daily Commission Breakdown Box */}
      <div className="bg-white rounded-[24px] p-6 border border-black/5 shadow-sm" id="commission-breakdown-card">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-4 pb-3 border-b border-black/5">
          <div>
            <h3 className="font-extrabold text-[16px]">Daily Commission & Earnings Breakdown</h3>
            <p className="text-[12px] text-black/50 mt-0.5">
              Transparent split: 80% to rider, 20% platform dispatch & insurance fee
            </p>
          </div>
          <div className="flex bg-[#F5F5F7] rounded-full p-1 text-[12px] font-semibold">
            <button
              onClick={() => setFilterPeriod('today')}
              className={`px-3 py-1 rounded-full transition ${filterPeriod === 'today' ? 'bg-white shadow-sm font-bold text-black' : 'text-black/60'}`}
            >
              Today
            </button>
            <button
              onClick={() => setFilterPeriod('week')}
              className={`px-3 py-1 rounded-full transition ${filterPeriod === 'week' ? 'bg-white shadow-sm font-bold text-black' : 'text-black/60'}`}
            >
              This Week
            </button>
          </div>
        </div>

        <div className="grid sm:grid-cols-4 gap-3 text-center">
          <div className="p-3.5 bg-[#F5F5F7] rounded-2xl">
            <div className="text-[11px] uppercase font-bold text-black/40">Gross Fare Booked</div>
            <div className="text-[18px] font-extrabold text-black mt-1">
              GHS {filterPeriod === 'today' ? todayGross.toFixed(2) : (todayGross * 4.2).toFixed(2)}
            </div>
            <div className="text-[11px] text-black/50 mt-0.5">Total customer payments</div>
          </div>

          <div className="p-3.5 bg-[#F5F5F7] rounded-2xl">
            <div className="text-[11px] uppercase font-bold text-black/40">Platform Fee (20%)</div>
            <div className="text-[18px] font-extrabold text-amber-700 mt-1">
              - GHS {filterPeriod === 'today' ? todayCommission.toFixed(2) : (todayCommission * 4.2).toFixed(2)}
            </div>
            <div className="text-[11px] text-black/50 mt-0.5">Dispatch, GPS & support</div>
          </div>

          <div className="p-3.5 bg-[#F5F5F7] rounded-2xl">
            <div className="text-[11px] uppercase font-bold text-black/40">Tips & Fuel Bonuses</div>
            <div className="text-[18px] font-extrabold text-green-700 mt-1">
              + GHS {filterPeriod === 'today' ? '25.00' : '95.00'}
            </div>
            <div className="text-[11px] text-black/50 mt-0.5">100% rider kept (0% fee)</div>
          </div>

          <div className="p-3.5 bg-green-50/70 border border-green-200/60 rounded-2xl">
            <div className="text-[11px] uppercase font-bold text-green-800">Your Net Earnings</div>
            <div className="text-[18px] font-extrabold text-green-900 mt-1">
              GHS {filterPeriod === 'today' ? todayNet.toFixed(2) : (todayNet * 4.2).toFixed(2)}
            </div>
            <div className="text-[11px] text-green-700 font-semibold mt-0.5">Deposited into wallet</div>
          </div>
        </div>
      </div>

      {/* Transaction & Payout History */}
      <div className="bg-white rounded-[24px] p-6 border border-black/5 shadow-sm" id="transaction-history-table">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-extrabold text-[16px]">Transaction History</h3>
            <p className="text-[12px] text-black/50 mt-0.5">Trips, tips, platform adjustments, and MoMo cashouts</p>
          </div>
          <span className="text-[11px] font-bold px-3 py-1 bg-[#F5F5F7] text-black/70 rounded-full">
            {transactions.length} records
          </span>
        </div>

        <div className="divide-y divide-black/5">
          {transactions.map(txn => {
            const isCredit = txn.amount > 0
            const isPending = txn.status === 'pending'
            return (
              <div key={txn.id} className="py-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center text-[16px] flex-shrink-0 ${
                      txn.type === 'payout_momo' || txn.type === 'payout_bank'
                        ? 'bg-amber-100 text-amber-800'
                        : txn.type === 'tip'
                        ? 'bg-purple-100 text-purple-800'
                        : txn.type === 'bonus'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-green-100 text-green-800'
                    }`}
                  >
                    {txn.type === 'payout_momo' || txn.type === 'payout_bank' ? '💸' : txn.type === 'tip' ? '🎁' : txn.type === 'bonus' ? '⚡' : '🛵'}
                  </div>
                  <div className="min-w-0">
                    <div className="font-bold text-[13px] text-black truncate">{txn.title}</div>
                    <div className="text-[11px] text-black/50 flex items-center gap-2 mt-0.5">
                      <span>{txn.date}</span>
                      <span>•</span>
                      <span className="font-mono">{txn.id}</span>
                      {txn.grossAmount && (
                        <>
                          <span>•</span>
                          <span>Gross: GHS {txn.grossAmount.toFixed(2)} (-20% WDS fee)</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                <div className="text-right flex-shrink-0">
                  <div className={`font-extrabold text-[14px] ${isCredit ? 'text-green-700' : 'text-black'}`}>
                    {isCredit ? '+' : ''}GHS {Math.abs(txn.amount).toFixed(2)}
                  </div>
                  <div className="mt-0.5">
                    <span
                      className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        isPending
                          ? 'bg-amber-100 text-amber-800 animate-pulse'
                          : 'bg-black/5 text-black/60'
                      }`}
                    >
                      {txn.status}
                    </span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* Payout Request Modal */}
      {showPayoutModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            onClick={() => setShowPayoutModal(false)}
          ></div>
          <div className="relative bg-white w-full max-w-[420px] rounded-[28px] p-6 shadow-2xl border border-black/10">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-extrabold text-[18px]">Request MoMo Cashout</h3>
              <button
                onClick={() => setShowPayoutModal(false)}
                className="w-8 h-8 rounded-full bg-black/5 flex items-center justify-center text-black/60 hover:bg-black/10"
              >
                ×
              </button>
            </div>

            <p className="text-[12px] text-black/60 mb-4">
              Funds will be disbursed instantly to your registered mobile money account via Paystack/MTN.
            </p>

            <form onSubmit={handleRequestPayout} className="space-y-4">
              <div>
                <label className="block text-[11px] font-bold uppercase text-black/50 mb-1">
                  Cashout Amount (Available: GHS {availableBalance.toFixed(2)})
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-3 text-[14px] font-bold text-black/40">GHS</span>
                  <input
                    type="number"
                    step="1"
                    min="5"
                    max={availableBalance}
                    value={payoutAmount}
                    onChange={e => setPayoutAmount(e.target.value)}
                    placeholder="e.g. 50"
                    className="w-full h-[48px] bg-[#F5F5F7] border border-black/10 rounded-2xl pl-14 pr-4 font-bold text-[16px] focus:outline-none focus:border-black"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-black/50 mb-1">
                  Mobile Money Provider
                </label>
                <select
                  value={payoutNetwork}
                  onChange={e => setPayoutNetwork(e.target.value)}
                  className="w-full h-[48px] bg-[#F5F5F7] border border-black/10 rounded-2xl px-4 text-[13px] font-semibold focus:outline-none"
                >
                  <option value="MTN Mobile Money">MTN Mobile Money</option>
                  <option value="Telecel Cash">Telecel Cash (Vodafone)</option>
                  <option value="AT Money">AT Money (AirtelTigo)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-black/50 mb-1">
                  Registered Recipient Phone Number
                </label>
                <input
                  type="text"
                  value={payoutPhone}
                  onChange={e => setPayoutPhone(e.target.value)}
                  className="w-full h-[48px] bg-[#F5F5F7] border border-black/10 rounded-2xl px-4 text-[13px] font-mono focus:outline-none"
                  required
                />
              </div>

              <div className="p-3 bg-amber-50 rounded-xl text-[11px] text-amber-800 border border-amber-200/50">
                Zero cashout withdrawal fee. Processed via Ghana interbank mobile settlement.
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPayoutModal(false)}
                  className="flex-1 h-[46px] rounded-full bg-black/5 font-bold text-[13px] hover:bg-black/10 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 h-[46px] rounded-full bg-[#FFC700] text-black font-extrabold text-[13px] hover:bg-[#e6b400] transition"
                >
                  Confirm Payout →
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
