'use client'

import { useState } from 'react'
import dynamic from 'next/dynamic'
import { RouteLoadingFallback } from '@/components/RouteLoadingFallback'
import RiderWallet from '@/components/views/RiderWallet'

// Heavy map - lazy loaded only when rider view is needed
const MapComponent = dynamic(() => import('@/components/Map'), {
  ssr: false,
  loading: () => <div className="h-[320px] bg-[#F5F5F7] rounded-[18px] animate-pulse flex items-center justify-center text-[12px] text-black/40">Loading rider map...</div>
})

const JobCard = dynamic(() => import('@/components/JobCard'), {
  loading: () => <div className="h-[100px] bg-white rounded-[22px] animate-pulse border" />
})

interface RiderViewProps {
  currentUser: any
  orders?: any[]
  onAcceptJob: (job: any) => void
  onUpdateStatus?: (orderId: string, status: string) => void
}

export default function RiderView({ currentUser, orders = [], onAcceptJob, onUpdateStatus }: RiderViewProps) {
  const [activeTab, setActiveTab] = useState<'deliveries' | 'wallet'>('deliveries')

  // Convert live pending orders to available jobs if present
  const pendingOrders = orders.filter((o: any) => o.status === 'pending')
  const myAssignedOrders = orders.filter((o: any) => (o.riderId === currentUser?.id || o.rider === currentUser?.name) && o.status !== 'delivered')

  const defaultJobs = [
    { id: 'WDS-89', from: 'Osu, Oxford St', to: 'Airport Residential', fee: 'GHS 28', dist: '3.2km', type: 'Document', urgent: true },
    { id: 'WDS-93', from: 'East Legon, Bawaleshie', to: 'Madina, Zongo', fee: 'GHS 38', dist: '6.1km', type: 'Parcel', urgent: false },
    { id: 'WDS-94', from: 'Kaneshie Market', to: 'Dansoman', fee: 'GHS 52', dist: '8.4km', type: 'Grocery', urgent: false },
  ]

  const liveJobs = pendingOrders.length > 0 
    ? pendingOrders.map((o: any) => ({
        id: o.id,
        from: o.pickup,
        to: o.dropoff,
        fee: o.price,
        dist: o.distanceKm ? `${o.distanceKm}km` : '5.2km',
        type: o.type,
        urgent: o.express || false,
      }))
    : defaultJobs

  return (
    <div className="max-w-[1440px] mx-auto px-4 md:px-8 py-6">
      {/* Rider Header Bar */}
      <div className="bg-black text-white rounded-[28px] p-6 flex flex-wrap items-center justify-between gap-4 mb-6 shadow-md">
        <div>
          <div className="flex items-center gap-2">
            <span className="font-bold text-[20px]">{currentUser?.name || 'Kwame Asare'}</span>
            <span className="px-2.5 py-0.5 bg-[#FFC700] text-black text-[11px] font-extrabold rounded-full">Active Courier</span>
          </div>
          <div className="text-[13px] text-white/60 mt-1">
            {currentUser?.vehicle || 'Motorbike'} • {currentUser?.plate || 'GR 4821-23'} • 312 deliveries completed
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-[11px] uppercase tracking-wider text-white/40 font-bold">Today's Earnings</div>
            <div className="text-[28px] font-extrabold text-[#FFC700]">GHS {currentUser?.earnings || 286}</div>
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between mb-6 pb-2 border-b border-black/5">
        <div className="flex bg-[#F5F5F7] rounded-full p-1 border border-black/5" id="rider-nav-tabs">
          <button
            id="tab-deliveries-button"
            onClick={() => setActiveTab('deliveries')}
            className={`flex items-center gap-2 px-5 h-9 rounded-full text-[13px] font-bold transition ${
              activeTab === 'deliveries' ? 'bg-white text-black shadow-sm' : 'text-black/60 hover:text-black'
            }`}
          >
            <span>🏍️ Available Trips</span>
            {liveJobs.length > 0 && (
              <span className="px-2 py-0.2 bg-black text-[#FFC700] rounded-full text-[10px] font-extrabold">
                {liveJobs.length}
              </span>
            )}
          </button>
          <button
            id="tab-wallet-button"
            onClick={() => setActiveTab('wallet')}
            className={`flex items-center gap-2 px-5 h-9 rounded-full text-[13px] font-bold transition ${
              activeTab === 'wallet' ? 'bg-white text-black shadow-sm' : 'text-black/60 hover:text-black'
            }`}
          >
            <span>💳 Rider Wallet</span>
            <span className="w-2 h-2 rounded-full bg-green-500"></span>
          </button>
        </div>

        {activeTab === 'deliveries' && (
          <span className="hidden sm:flex items-center gap-1.5 px-3 py-1 bg-green-50 text-green-700 rounded-full text-[11px] font-bold border border-green-200">
            <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> Live Stream Active
          </span>
        )}
      </div>

      {/* View Content */}
      {activeTab === 'wallet' ? (
        <RiderWallet currentUser={currentUser} orders={orders} />
      ) : (
        <div className="grid lg:grid-cols-[1fr_380px] gap-6">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-extrabold text-[20px]">Live Available Deliveries</h2>
              <span className="text-[12px] text-black/50">Auto-assigning Greater Accra corridors</span>
            </div>
            <div className="space-y-3">
              {liveJobs.map(j => (
                <JobCard key={j.id} id={j.id} from={j.from} to={j.to} fee={j.fee} dist={j.dist} type={j.type} urgent={j.urgent} onAccept={() => onAcceptJob(j)} />
              ))}
            </div>
            <div className="mt-6 p-4 bg-white rounded-2xl border border-black/5 text-[12px] flex items-center justify-between">
              <span className="text-black/60">GPS Telemetry broadcast interval</span>
              <span className="font-semibold text-black">Active • Auto-syncing</span>
            </div>
          </div>

          <div className="space-y-4">
            <div className="bg-white rounded-[24px] p-5 border border-black/5 shadow-sm">
              <h3 className="font-bold text-[15px] mb-3">My Active Delivery</h3>
              {myAssignedOrders.length > 0 ? (
                <div className="space-y-3">
                  {myAssignedOrders.map((o: any) => (
                    <div key={o.id} className="p-3.5 bg-[#F5F5F7] rounded-xl text-[13px] space-y-2 border border-black/5">
                      <div className="flex justify-between font-bold">
                        <span>{o.id}</span>
                        <span className="text-xs px-2.5 py-0.5 bg-[#FFC700] rounded-full uppercase font-extrabold">{o.status}</span>
                      </div>
                      <div className="text-xs text-black/70 font-medium">{o.pickup} → {o.dropoff}</div>
                      <div className="text-xs font-extrabold text-black">{o.price}</div>
                      {onUpdateStatus && (
                        <div className="flex gap-2 pt-2">
                          {o.status === 'accepted' && (
                            <button
                              onClick={() => onUpdateStatus(o.id, 'picked_up')}
                              className="flex-1 py-2 bg-black text-white text-xs font-bold rounded-xl hover:bg-black/80 transition"
                            >
                              Mark Picked Up
                            </button>
                          )}
                          {o.status === 'picked_up' && (
                            <button
                              onClick={() => onUpdateStatus(o.id, 'on_the_way')}
                              className="flex-1 py-2 bg-black text-white text-xs font-bold rounded-xl hover:bg-black/80 transition"
                            >
                              Start Transit
                            </button>
                          )}
                          {o.status === 'on_the_way' && (
                            <button
                              onClick={() => onUpdateStatus(o.id, 'delivered')}
                              className="flex-1 py-2 bg-green-600 text-white text-xs font-bold rounded-xl hover:bg-green-700 transition"
                            >
                              Mark Delivered
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-[13px] text-black/50 text-center py-8 border border-dashed rounded-2xl">
                  No active delivery. Accept a job from the list.
                </div>
              )}
            </div>
            <div className="bg-white rounded-[24px] p-2 border border-black/5 shadow-sm"><MapComponent height="320px" /></div>
          </div>
        </div>
      )}
    </div>
  )
}
