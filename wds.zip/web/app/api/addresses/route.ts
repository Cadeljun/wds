import { NextRequest, NextResponse } from 'next/server'
import { verifyUser, checkRateLimit } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const addressSchema = z.object({
  title: z.string().optional().default('Home'),
  address: z.string().min(3, 'Address is required'),
  city: z.string().optional().default('Accra'),
  region: z.string().optional().default('Greater Accra'),
  latitude: z.number(),
  longitude: z.number(),
  is_default: z.boolean().optional().default(false),
})

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      const { data, error } = await supabase
        .from('addresses')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (error) throw error
      return NextResponse.json({ success: true, addresses: data || [] }, { status: 200, headers: corsHeaders })
    }

    return NextResponse.json({
      success: true,
      addresses: [
        {
          id: 'addr_default',
          user_id: user.id,
          title: 'Home',
          address: 'East Legon, American House',
          city: 'Accra',
          region: 'Greater Accra',
          latitude: 5.6365,
          longitude: -0.1645,
          is_default: true,
        },
        {
          id: 'addr_work',
          user_id: user.id,
          title: 'Office',
          address: 'Osu, Oxford Street',
          city: 'Accra',
          region: 'Greater Accra',
          latitude: 5.5560,
          longitude: -0.1760,
          is_default: false,
        }
      ]
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('GET /api/addresses error:', err)
    return NextResponse.json({ error: err.message || 'Failed to fetch addresses' }, { status: 500, headers: corsHeaders })
  }
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)
  const ip = request.headers.get('x-forwarded-for') || 'unknown'

  try {
    const rateLimit = checkRateLimit(`addresses:${ip}`, 20, 60000)
    if (!rateLimit.allowed) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429, headers: corsHeaders })
    }

    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const body = await request.json()
    const parsed = addressSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.format() }, { status: 400, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      // Find customer record if exists
      const { data: customer } = await supabase
        .from('customers')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle()

      const { data, error } = await supabase
        .from('addresses')
        .insert({
          user_id: user.id,
          customer_id: customer?.id || null,
          title: parsed.data.title,
          address: parsed.data.address,
          city: parsed.data.city,
          region: parsed.data.region,
          latitude: parsed.data.latitude,
          longitude: parsed.data.longitude,
          is_default: parsed.data.is_default,
        })
        .select()
        .single()

      if (error) throw error
      return NextResponse.json({ success: true, address: data }, { status: 201, headers: corsHeaders })
    }

    return NextResponse.json({
      success: true,
      address: {
        id: `addr_${Date.now()}`,
        user_id: user.id,
        ...parsed.data,
        created_at: new Date().toISOString()
      }
    }, { status: 201, headers: corsHeaders })
  } catch (err: any) {
    console.error('POST /api/addresses error:', err)
    return NextResponse.json({ error: err.message || 'Failed to create address' }, { status: 500, headers: corsHeaders })
  }
}
