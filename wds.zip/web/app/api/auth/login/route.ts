import { NextRequest, NextResponse } from 'next/server'
import { loginSchema, getFieldErrors } from '@/lib/validation'
import { sanitizeGhanaPhone, sanitizeEmail } from '@/lib/sanitize'
import { checkRateLimit } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const ALLOWED_ORIGINS = [
  'https://wds.com.gh',
  'https://www.wds.com.gh',
  'http://localhost:3000',
  'http://localhost:5173',
]

function getCorsHeaders(origin: string | null) {
  const isAllowed = origin && ALLOWED_ORIGINS.includes(origin)
  return {
    'Access-Control-Allow-Origin': isAllowed ? origin : ALLOWED_ORIGINS[0],
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)
  const ip = request.headers.get('x-forwarded-for') || 'unknown'

  try {
    // Rate limiting: 5 login attempts per IP per 15 mins
    const rateLimit = checkRateLimit(`login:${ip}`, 5, 15 * 60 * 1000)
    if (!rateLimit.allowed) {
      return NextResponse.json(
        { success: false, error: 'Too many login attempts. Please wait 15 minutes.' },
        { status: 429, headers: corsHeaders }
      )
    }

    const body = await request.json()

    const result = loginSchema.safeParse(body)

    if (!result.success) {
      const errors = getFieldErrors(result.error)
      return NextResponse.json(
        { success: false, error: 'Validation failed', errors },
        { status: 400, headers: corsHeaders }
      )
    }

    const sanitized = {
      loginType: result.data.loginType || (result.data.email ? 'email' : 'phone'),
      phone: result.data.phone ? sanitizeGhanaPhone(result.data.phone) : '',
      email: result.data.email ? sanitizeEmail(result.data.email) : '',
      password: result.data.password,
    }

    console.log('Login attempt (sanitized):', { 
      loginType: sanitized.loginType,
      phone: sanitized.phone ? sanitized.phone.substring(0, 5) + '***' : undefined,
      email: sanitized.email ? sanitized.email.replace(/(?<=.).(?=.*@)/g, '*') : undefined,
      password: '***' 
    })

    const demoUsers = [
      { phone: '0244123456', email: 'ama.mensah@gmail.com', password: '123456', role: 'customer', name: 'Ama Mensah' },
      { phone: '0244987654', email: 'kwame.asare@gmail.com', password: '123456', role: 'rider', name: 'Kwame Asare' },
      { phone: '0244000000', email: 'admin@wds.com.gh', password: 'admin123', role: 'admin', name: 'Williams Admin' },
    ]

    let user = demoUsers.find(u => {
      if (sanitized.loginType === 'email' || (sanitized.email && !sanitized.phone)) {
        return u.email.toLowerCase() === sanitized.email.toLowerCase() && u.password === sanitized.password
      }
      return u.phone === sanitized.phone && u.password === sanitized.password
    })

    // Check database if not found in demo users
    if (!user) {
      const supabase = getServerSupabase()
      if (supabase) {
        try {
          let query = supabase.from('customers').select('*')
          if (sanitized.loginType === 'email' || (sanitized.email && !sanitized.phone)) {
            query = query.eq('email', sanitized.email)
          } else {
            query = query.eq('phone', sanitized.phone)
          }
          const { data } = await query.maybeSingle()
          if (data) {
            user = {
              phone: data.phone || sanitized.phone,
              email: data.email || sanitized.email,
              password: sanitized.password,
              role: 'customer',
              name: data.full_name || 'Customer',
            }
          }
        } catch {
          // ignore error
        }
      }
    }

    if (!user) {
      const isEmail = sanitized.loginType === 'email' || (sanitized.email && !sanitized.phone)
      return NextResponse.json(
        { 
          success: false, 
          error: isEmail
            ? 'Invalid email or password. Demo: ama.mensah@gmail.com / 123456, kwame.asare@gmail.com / 123456, admin@wds.com.gh / admin123'
            : 'Invalid phone or password. Demo: Customer 0244123456 / 123456, Rider 0244987654 / 123456, Admin 0244000000 / admin123' 
        },
        { status: 401, headers: corsHeaders }
      )
    }

    return NextResponse.json(
      { success: true, message: 'Login successful', user },
      { status: 200, headers: corsHeaders }
    )
  } catch (error) {
    console.error('Login API error:', error)
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Validation failed', errors: getFieldErrors(error) },
        { status: 400, headers: corsHeaders }
      )
    }
    return NextResponse.json(
      { success: false, error: 'Failed to login. Please try again.' },
      { status: 500, headers: corsHeaders }
    )
  }
}
