import { NextRequest, NextResponse } from 'next/server'
import { defaultPricing, PricingSettings } from '@/lib/pricing'
import { getServerSupabase } from '@/lib/server-supabase'
import { verifyAdmin } from '@/lib/auth'
import { z } from 'zod'

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const supabase = getServerSupabase()
    if (supabase) {
      const { data } = await supabase.from('settings').select('value').eq('key', 'pricing').maybeSingle()
      if (data?.value) {
        return NextResponse.json({ success: true, pricing: data.value }, { status: 200, headers: corsHeaders })
      }
    }
    return NextResponse.json({ success: true, pricing: defaultPricing }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    return NextResponse.json({ success: true, pricing: defaultPricing }, { status: 200, headers: corsHeaders })
  }
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const admin = await verifyAdmin(request)
    if (!admin) {
      return NextResponse.json({ error: 'Forbidden - Admin credentials required to modify system pricing' }, { status: 403, headers: corsHeaders })
    }

    const body = await request.json()
    const supabase = getServerSupabase()

    if (supabase) {
      const { data, error } = await supabase
        .from('settings')
        .upsert({
          key: 'pricing',
          value: body,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) throw error
      return NextResponse.json({ success: true, pricing: data.value }, { status: 200, headers: corsHeaders })
    }

    return NextResponse.json({ success: true, pricing: body, message: 'Pricing updated (demo simulated)' }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('POST /api/pricing error:', err)
    return NextResponse.json({ error: err.message || 'Failed to update pricing' }, { status: 500, headers: corsHeaders })
  }
}
