import { NextRequest } from 'next/server'
import {
  subscribeToEvents,
  getLiveOrders,
  getLiveRiders,
  RealtimeEvent,
} from '@/lib/realtime-service'

export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  const encoder = new TextEncoder()

  const stream = new ReadableStream({
    start(controller) {
      // 1. Send initial state snapshot on connection
      const initialPayload: RealtimeEvent = {
        id: `init_${Date.now()}`,
        type: 'order:updated',
        timestamp: new Date().toISOString(),
        payload: {
          orders: getLiveOrders(),
          riders: getLiveRiders(),
          status: 'connected',
        },
      }

      controller.enqueue(
        encoder.encode(`event: init\ndata: ${JSON.stringify(initialPayload.payload)}\n\n`)
      )

      // 2. Subscribe to real-time events broadcasted by mutations
      const unsubscribe = subscribeToEvents((event) => {
        try {
          const sseChunk = `event: ${event.type}\ndata: ${JSON.stringify(event.payload)}\n\n`
          controller.enqueue(encoder.encode(sseChunk))
        } catch {
          unsubscribe()
        }
      })

      // 3. Heartbeat / Keep-alive every 15s to keep connection healthy through proxies
      const heartbeatInterval = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: ping\n\n`))
        } catch {
          clearInterval(heartbeatInterval)
          unsubscribe()
        }
      }, 15000)

      // 4. Handle connection close
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeatInterval)
        unsubscribe()
        try {
          controller.close()
        } catch {}
      })
    },
  })

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'Access-Control-Allow-Origin': '*',
    },
  })
}
