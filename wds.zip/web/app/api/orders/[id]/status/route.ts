import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { upsertLiveOrder, getLiveOrder, LiveOrder } from '@/lib/realtime-service'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const updateStatusSchema = z.object({
  status: z.enum(['pending', 'accepted', 'picked_up', 'on_the_way', 'delivered', 'cancelled', 'failed']),
  riderId: z.string().optional(),
  riderName: z.string().optional(),
  etaMinutes: z.number().optional(),
  notes: z.string().optional(),
})

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const orderId = params.id
    const body = await request.json()
    const parsed = updateStatusSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid update payload', details: parsed.error.format() }, { status: 400 })
    }

    const { status, riderId, riderName, etaMinutes, notes } = parsed.data
    const supabase = getServerSupabase()

    // 1. Update Database if configured
    if (supabase) {
      const dbUpdates: any = {
        status,
        order_status: status,
        updated_at: new Date().toISOString(),
      }
      if (riderId) {
        dbUpdates.rider_id = riderId
        dbUpdates.assigned_rider_id = riderId
      }
      if (status === 'delivered') {
        dbUpdates.delivered_at = new Date().toISOString()
      }

      const { data: dbOrder, error: dbError } = await supabase
        .from('orders')
        .update(dbUpdates)
        .eq('id', orderId)
        .select()
        .maybeSingle()

      if (!dbError && dbOrder) {
        // Record status history
        try {
          await supabase
            .from('order_status_history')
            .insert({
              order_id: orderId,
              status,
              changed_by: user.id,
              changed_by_role: user.role,
              notes: notes || `Order updated to ${status} by ${user.role}`,
            })
        } catch {
          // ignore history insert error
        }

        // Update in-memory real-time sync
        const liveUpdated = upsertLiveOrder({
          id: orderId,
          status: status as any,
          ...(riderId ? { riderId } : {}),
          ...(riderName ? { riderName } : {}),
          ...(etaMinutes !== undefined ? { etaMinutes } : {}),
        })

        return NextResponse.json({ success: true, order: dbOrder, live: liveUpdated })
      }
    }

    // 2. Fallback in-memory
    const existing = getLiveOrder(orderId)
    const updatePayload: Partial<LiveOrder> & { id: string } = {
      id: orderId,
      status: status as any,
      ...(riderId ? { riderId } : {}),
      ...(riderName ? { riderName } : {}),
      ...(etaMinutes !== undefined ? { etaMinutes } : {}),
    }

    const updated = upsertLiveOrder(updatePayload)
    return NextResponse.json({ success: true, order: updated })
  } catch (err) {
    console.error('Update order status error:', err)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const orderId = params.id
  const supabase = getServerSupabase()

  if (supabase) {
    const { data: dbOrder } = await supabase
      .from('orders')
      .select('*, order_status_history(*)')
      .eq('id', orderId)
      .maybeSingle()

    if (dbOrder) {
      return NextResponse.json({ success: true, order: dbOrder })
    }
  }

  const order = getLiveOrder(orderId)
  if (!order) {
    return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  }

  return NextResponse.json({ success: true, order })
}
