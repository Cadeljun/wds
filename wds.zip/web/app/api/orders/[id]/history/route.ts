import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const orderId = params.id
    const supabase = getServerSupabase()

    if (supabase) {
      // Fetch status history
      const { data, error } = await supabase
        .from('order_status_history')
        .select('*')
        .eq('order_id', orderId)
        .order('created_at', { ascending: true })

      if (error) throw error

      return NextResponse.json({
        success: true,
        order_id: orderId,
        history: data || [],
      }, { status: 200, headers: corsHeaders })
    }

    // Demo fallback with realistic status timestamps
    const now = Date.now()
    return NextResponse.json({
      success: true,
      order_id: orderId,
      history: [
        {
          id: 'hist_1',
          order_id: orderId,
          status: 'pending',
          changed_by_role: 'customer',
          notes: 'Order placed by customer',
          created_at: new Date(now - 1000 * 60 * 30).toISOString(),
        },
        {
          id: 'hist_2',
          order_id: orderId,
          status: 'accepted',
          changed_by_role: 'rider',
          notes: 'Rider assigned and accepted delivery request',
          created_at: new Date(now - 1000 * 60 * 20).toISOString(),
        },
        {
          id: 'hist_3',
          order_id: orderId,
          status: 'picked_up',
          changed_by_role: 'rider',
          notes: 'Rider collected package from pickup address',
          created_at: new Date(now - 1000 * 60 * 10).toISOString(),
        }
      ]
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('GET /api/orders/[id]/history error:', err)
    return NextResponse.json({ error: err.message || 'Failed to fetch status history' }, { status: 500, headers: corsHeaders })
  }
}
