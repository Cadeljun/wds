import { NextRequest, NextResponse } from 'next/server'
import { bookingFormSchema, getFieldErrors } from '@/lib/validation'
import { sanitize, sanitizeAddress, sanitizeName, sanitizeGhanaPhone } from '@/lib/sanitize'
import { verifyUser, checkRateLimit } from '@/lib/auth'
import { z } from 'zod'
import { createClient } from '@supabase/supabase-js'
import { getServerSupabase } from '@/lib/server-supabase'
import { upsertLiveOrder, getLiveOrders } from '@/lib/realtime-service'
import { calcPrice } from '@/lib/pricing'

const ALLOWED_ORIGINS = [
  'https://wds.com.gh',
  'https://www.wds.com.gh',
  'http://localhost:3000',
  'http://localhost:5173',
]

function getCorsHeaders(origin: string | null) {
  const isAllowed = origin && ALLOWED_ORIGINS.includes(origin)
  return {
    'Access-Control-Allow-Origin': isAllowed ? origin : ALLOWED_ORIGINS[0],
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, x-internal-secret',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)
  const ip = request.headers.get('x-forwarded-for') || request.headers.get('x-real-ip') || 'unknown'

  try {
    // Rate limiting: 10 orders per IP per minute
    const rateLimit = checkRateLimit(`orders:${ip}`, 10, 60000)
    if (!rateLimit.allowed) {
      return NextResponse.json(
        { success: false, error: 'Too many orders. Please wait a minute and try again.' },
        { status: 429, headers: corsHeaders }
      )
    }

    // Authenticate user & derive identity from token
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json(
        { success: false, error: 'Unauthorized. Please log in to create orders.' },
        { status: 401, headers: corsHeaders }
      )
    }

    const body = await request.json()

    // Server-side validation
    const validationResult = bookingFormSchema.safeParse(body)
    if (!validationResult.success) {
      const errors = getFieldErrors(validationResult.error)
      return NextResponse.json(
        { success: false, error: 'Validation failed', errors },
        { status: 400, headers: corsHeaders }
      )
    }

    // XSS Sanitization
    const sanitizedData = {
      pickup_address: sanitizeAddress(validationResult.data.pickup_address),
      dropoff_address: sanitizeAddress(validationResult.data.dropoff_address),
      package_type: validationResult.data.package_type,
      description: validationResult.data.description ? sanitize(validationResult.data.description) : '',
      recipient_name: validationResult.data.recipient_name ? sanitizeName(validationResult.data.recipient_name) : '',
      recipient_phone: validationResult.data.recipient_phone ? sanitizeGhanaPhone(validationResult.data.recipient_phone) : '',
      payment_method: validationResult.data.payment_method,
      express: validationResult.data.express || false,
    }

    const customer_id = user.id
    const distance_km = 8.4

    // Use centralized pricing module
    const { total: price } = calcPrice(distance_km, sanitizedData.package_type as any, sanitizedData.express)

    const pickup_lat = Number(body.pickup_lat) || 5.6365
    const pickup_lng = Number(body.pickup_lng) || -0.1645
    const dropoff_lat = Number(body.dropoff_lat) || 5.5560
    const dropoff_lng = Number(body.dropoff_lng) || -0.1760

    // Save to Database via getServerSupabase
    const supabase = getServerSupabase()

    if (supabase) {
      // 1. Ensure customer record exists
      try {
        await supabase
          .from('customers')
          .upsert({
            user_id: customer_id,
            full_name: user.phone || 'Customer',
            phone: user.phone || '0244123456',
          }, { onConflict: 'user_id' })
      } catch {
        // ignore customer upsert error
      }

      // 2. Insert into orders table with both canonical and extended columns
      const { data, error } = await supabase
        .from('orders')
        .insert({
          customer_id,
          pickup_address: sanitizedData.pickup_address,
          pickup_lat,
          pickup_lng,
          dropoff_address: sanitizedData.dropoff_address,
          delivery_address: sanitizedData.dropoff_address,
          dropoff_lat,
          dropoff_lng,
          package_type: sanitizedData.package_type,
          description: sanitizedData.description,
          package_description: sanitizedData.description,
          recipient_name: sanitizedData.recipient_name,
          recipient_phone: sanitizedData.recipient_phone,
          distance_km,
          price,
          delivery_fee: price,
          payment_method: sanitizedData.payment_method,
          payment_status: sanitizedData.payment_method === 'cash' ? 'cash_on_delivery' : 'pending',
          status: 'pending',
          order_status: 'pending',
          express: sanitizedData.express,
        })
        .select()
        .single()

      if (!error && data) {
        // Also sync to live real-time network
        upsertLiveOrder({
          id: data.id,
          orderCode: data.order_code || data.id,
          customerId: customer_id,
          customerName: user.phone || 'Customer',
          pickup: sanitizedData.pickup_address,
          pickupCoords: { lat: pickup_lat, lng: pickup_lng },
          dropoff: sanitizedData.dropoff_address,
          dropoffCoords: { lat: dropoff_lat, lng: dropoff_lng },
          type: sanitizedData.package_type,
          description: sanitizedData.description,
          recipientName: sanitizedData.recipient_name,
          recipientPhone: sanitizedData.recipient_phone,
          price: `GHS ${price}`,
          paymentMethod: sanitizedData.payment_method,
          status: 'pending',
          distanceKm: distance_km,
          etaMinutes: 25,
        })

        return NextResponse.json(
          { success: true, message: 'Order created and persisted to database', order: data, price },
          { status: 201, headers: corsHeaders }
        )
      }
    }

    // In-memory fallback if Supabase not configured in current runtime
    const orderId = 'WDS-' + Date.now().toString().slice(-6)
    const liveOrder = upsertLiveOrder({
      id: orderId,
      orderCode: orderId,
      customerId: customer_id,
      customerName: user.phone || 'Customer',
      pickup: sanitizedData.pickup_address,
      pickupCoords: { lat: pickup_lat, lng: pickup_lng },
      dropoff: sanitizedData.dropoff_address,
      dropoffCoords: { lat: dropoff_lat, lng: dropoff_lng },
      type: sanitizedData.package_type,
      description: sanitizedData.description,
      recipientName: sanitizedData.recipient_name,
      recipientPhone: sanitizedData.recipient_phone,
      price: `GHS ${price}`,
      paymentMethod: sanitizedData.payment_method,
      status: 'pending',
      distanceKm: distance_km,
      etaMinutes: 25,
    })

    return NextResponse.json(
      { success: true, message: 'Order created and broadcasted to dispatch network', order: liveOrder, price },
      { status: 201, headers: corsHeaders }
    )
  } catch (error) {
    console.error('Orders API error:', error)

    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: 'Validation failed', errors: getFieldErrors(error) },
        { status: 400, headers: getCorsHeaders(origin) }
      )
    }

    return NextResponse.json(
      { success: false, error: 'Failed to create order. Please try again.' },
      { status: 500, headers: corsHeaders }
    )
  }
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  const user = await verifyUser(request)
  if (!user) {
    return NextResponse.json(
      { success: false, error: 'Unauthorized' },
      { status: 401, headers: corsHeaders }
    )
  }

  const supabase = getServerSupabase()
  if (supabase) {
    let query = supabase.from('orders').select('*')
    if (user.role === 'rider') {
      query = query.or(`assigned_rider_id.eq.${user.id},rider_id.eq.${user.id},status.eq.pending,order_status.eq.pending`)
    } else if (user.role !== 'admin') {
      query = query.eq('customer_id', user.id)
    }
    const { data, error } = await query.order('created_at', { ascending: false })
    if (!error && data) {
      return NextResponse.json(
        { success: true, orders: data, user_id: user.id },
        { status: 200, headers: corsHeaders }
      )
    }
  }

  // Fetch live orders fallback
  const allOrders = getLiveOrders()
  const orders = user.role === 'admin'
    ? allOrders
    : user.role === 'rider'
    ? allOrders.filter(o => o.riderId === user.id || o.status === 'pending')
    : allOrders.filter(o => o.customerId === user.id)

  return NextResponse.json(
    { success: true, orders, user_id: user.id },
    { status: 200, headers: corsHeaders }
  )
}
