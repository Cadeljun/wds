import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { z } from 'zod'

// In-memory / demo storage for customer wallets
const walletStore: Record<string, { balance: number; transactions: any[] }> = {}

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

// GET /api/wallet - Get customer wallet balance and transactions
export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    const userId = user?.id || 'demo_customer'

    if (!walletStore[userId]) {
      walletStore[userId] = {
        balance: 125.00,
        transactions: [
          {
            id: 'TXN-8801',
            type: 'momo_topup',
            title: 'MTN Mobile Money Top-Up',
            amount: 100.00,
            date: 'Today 10:30 AM',
            status: 'completed',
            reference: 'MM-TOP-88012',
            network: 'MTN MoMo',
            phone: user?.phone || '0244123456',
          },
          {
            id: 'TXN-8742',
            type: 'delivery_payment',
            title: 'Delivery Fare #WDS-88 (Adabraka → Tema)',
            amount: -45.00,
            date: 'Yesterday 04:15 PM',
            status: 'completed',
            reference: 'WAL-PAY-87420',
            orderId: 'WDS-88',
          },
          {
            id: 'TXN-8690',
            type: 'momo_topup',
            title: 'Telecel Cash Top-Up',
            amount: 70.00,
            date: '16 Sep 02:00 PM',
            status: 'completed',
            reference: 'MM-TOP-86904',
            network: 'Telecel Cash',
            phone: user?.phone || '0244123456',
          },
        ],
      }
    }

    return NextResponse.json({
      success: true,
      wallet: walletStore[userId],
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Failed to fetch wallet' }, { status: 500, headers: corsHeaders })
  }
}

const topupSchema = z.object({
  amount: z.number().positive(),
  network: z.enum(['mtn', 'telecel', 'airteltigo']),
  phone: z.string().min(9),
  pin: z.string().optional(),
})

// POST /api/wallet - Top up or pay from wallet
export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    const userId = user?.id || 'demo_customer'
    const body = await request.json()

    if (!walletStore[userId]) {
      walletStore[userId] = { balance: 125.00, transactions: [] }
    }

    if (body.action === 'pay') {
      const amount = Number(body.amount)
      if (isNaN(amount) || amount <= 0) {
        return NextResponse.json({ error: 'Invalid delivery amount' }, { status: 400, headers: corsHeaders })
      }
      if (walletStore[userId].balance < amount) {
        return NextResponse.json({
          error: 'Insufficient wallet balance',
          balance: walletStore[userId].balance,
          required: amount,
        }, { status: 400, headers: corsHeaders })
      }

      walletStore[userId].balance -= amount
      const txn = {
        id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
        type: 'delivery_payment',
        title: body.title || `Delivery Fare Payment #${body.orderId || 'WDS'}`,
        amount: -amount,
        date: 'Just now',
        status: 'completed',
        reference: 'WAL-PAY-' + Date.now().toString().slice(-6),
        orderId: body.orderId,
      }
      walletStore[userId].transactions.unshift(txn)

      return NextResponse.json({
        success: true,
        message: `Successfully paid GHS ${amount.toFixed(2)} from Virtual Wallet`,
        balance: walletStore[userId].balance,
        transaction: txn,
      }, { status: 200, headers: corsHeaders })
    }

    // Default action: Top-up via MoMo
    const parsed = topupSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid top-up details', details: parsed.error.format() }, { status: 400, headers: corsHeaders })
    }

    const { amount, network, phone } = parsed.data
    const networkName = network === 'mtn' ? 'MTN MoMo' : network === 'telecel' ? 'Telecel Cash' : 'AT Money'

    walletStore[userId].balance += amount

    const txn = {
      id: 'TXN-' + Math.floor(1000 + Math.random() * 9000),
      type: 'momo_topup',
      title: `${networkName} Wallet Top-Up`,
      amount,
      date: 'Just now',
      status: 'completed',
      reference: 'MM-TOP-' + Math.floor(10000 + Math.random() * 90000),
      network: networkName,
      phone,
    }

    walletStore[userId].transactions.unshift(txn)

    return NextResponse.json({
      success: true,
      message: `Successfully credited GHS ${amount.toFixed(2)} via ${networkName}`,
      balance: walletStore[userId].balance,
      transaction: txn,
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    return NextResponse.json({ error: err.message || 'Top-up failed' }, { status: 500, headers: corsHeaders })
  }
}
