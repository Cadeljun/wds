import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const paymentSchema = z.object({
  order_id: z.string(),
  amount: z.number().positive(),
  payment_method: z.string().default('momo_mtn'),
  channel: z.string().optional().default('mobile_money'),
  customer_email: z.string().email().optional(),
})

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      let query = supabase.from('payments').select('*, orders(*)')
      if (user.role !== 'admin') {
        // Find user orders
        const { data: userOrders } = await supabase.from('orders').select('id').eq('customer_id', user.id)
        const orderIds = (userOrders || []).map(o => o.id)
        if (orderIds.length === 0) {
          return NextResponse.json({ success: true, payments: [] }, { status: 200, headers: corsHeaders })
        }
        query = query.in('order_id', orderIds)
      }
      const { data, error } = await query.order('created_at', { ascending: false })
      if (error) throw error
      return NextResponse.json({ success: true, payments: data || [] }, { status: 200, headers: corsHeaders })
    }

    // Demo fallback
    return NextResponse.json({
      success: true,
      payments: [
        {
          id: 'pay_demo_1',
          order_id: 'WDS-91',
          provider: 'paystack',
          amount: 35,
          currency: 'GHS',
          channel: 'mobile_money',
          payment_method: 'momo_mtn',
          payment_status: 'paid',
          transaction_reference: 'trx_demo_mtn_91',
          created_at: new Date(Date.now() - 3600000).toISOString(),
        }
      ]
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('GET /api/payments error:', err)
    return NextResponse.json({ error: err.message || 'Failed to list payments' }, { status: 500, headers: corsHeaders })
  }
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const body = await request.json()
    const parsed = paymentSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid payment parameters', details: parsed.error.format() }, { status: 400, headers: corsHeaders })
    }

    const { order_id, amount, payment_method, channel, customer_email } = parsed.data
    const reference = `WDS-PAY-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`

    const paystackSecret = process.env.PAYSTACK_SECRET_KEY
    const supabase = getServerSupabase()

    // If real Paystack Secret is present, initialize real transaction with Paystack API
    if (paystackSecret && !paystackSecret.includes('placeholder')) {
      const paystackRes = await fetch('https://api.paystack.co/transaction/initialize', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${paystackSecret}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: customer_email || `${user.phone || 'customer'}@wds.com.gh`,
          amount: Math.round(amount * 100), // convert to pesewas
          currency: 'GHS',
          reference,
          metadata: {
            order_id,
            user_id: user.id,
            payment_method,
          },
        }),
      })

      const paystackData = await paystackRes.json()
      if (!paystackRes.ok || !paystackData.status) {
        throw new Error(paystackData.message || 'Paystack initialization failed')
      }

      // Record in payments table
      if (supabase) {
        await supabase.from('payments').insert({
          order_id,
          provider: 'paystack',
          amount,
          currency: 'GHS',
          channel,
          payment_method,
          payment_status: 'pending',
          status: 'pending',
          transaction_reference: reference,
          transaction_ref: reference,
        })
      }

      return NextResponse.json({
        success: true,
        reference,
        authorization_url: paystackData.data.authorization_url,
        access_code: paystackData.data.access_code,
      }, { status: 200, headers: corsHeaders })
    }

    // Demo/Simulated Paystack initialization
    if (supabase) {
      await supabase.from('payments').insert({
        order_id,
        provider: 'paystack',
        amount,
        currency: 'GHS',
        channel,
        payment_method,
        payment_status: payment_method === 'cash' ? 'cash_on_delivery' : 'pending',
        status: payment_method === 'cash' ? 'cash_on_delivery' : 'pending',
        transaction_reference: reference,
        transaction_ref: reference,
      })
    }

    return NextResponse.json({
      success: true,
      reference,
      authorization_url: `https://checkout.paystack.com/demo-${reference}`,
      message: 'Payment initialized successfully (demo simulated)',
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('POST /api/payments error:', err)
    return NextResponse.json({ error: err.message || 'Failed to initialize payment' }, { status: 500, headers: corsHeaders })
  }
}
