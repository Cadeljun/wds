import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { updateRiderLocation, getLiveRiders } from '@/lib/realtime-service'
import { z } from 'zod'

const locationSchema = z.object({
  lat: z.number().min(-90).max(90),
  lng: z.number().min(-180).max(180),
  heading: z.number().optional(),
  speed: z.number().optional(),
})

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const riderId = params.id

    // Only allow rider to update their own location (or admin)
    if (user.role !== 'admin' && user.id !== riderId) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const parsed = locationSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid coordinates' }, { status: 400 })
    }

    const updated = updateRiderLocation({
      riderId,
      riderName: user.phone || 'Active Rider',
      lat: parsed.data.lat,
      lng: parsed.data.lng,
      heading: parsed.data.heading,
      speed: parsed.data.speed,
      updatedAt: new Date().toISOString(),
    })

    return NextResponse.json({ success: true, location: updated })
  } catch (err) {
    console.error('Update rider location error:', err)
    return NextResponse.json({ error: 'Internal Server Error' }, { status: 500 })
  }
}

export async function GET() {
  const riders = getLiveRiders()
  return NextResponse.json({ success: true, riders })
}
