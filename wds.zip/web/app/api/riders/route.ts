import { NextRequest, NextResponse } from 'next/server'
import { verifyUser } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const riderSchema = z.object({
  vehicle_type: z.enum(['motor', 'bicycle', 'car', 'van']).optional().default('motor'),
  license_plate: z.string().optional().default(''),
  current_status: z.enum(['offline', 'online', 'delivering']).optional().default('offline'),
  current_lat: z.number().optional(),
  current_lng: z.number().optional(),
})

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      const { data, error } = await supabase
        .from('riders')
        .select('*')
        .order('rating', { ascending: false })

      if (error) throw error
      return NextResponse.json({ success: true, riders: data || [] }, { status: 200, headers: corsHeaders })
    }

    // Demo fleet
    return NextResponse.json({
      success: true,
      riders: [
        {
          id: 'u_0244987654',
          full_name: 'Kwame Asare',
          phone: '0244987654',
          vehicle_type: 'motor',
          license_plate: 'GW-2044-24',
          current_status: 'online',
          rating: 4.9,
          total_deliveries: 42,
          total_earnings: 735,
          current_lat: 5.6037,
          current_lng: -0.1870,
        },
        {
          id: 'u_0244555888',
          full_name: 'Kofi Boateng',
          phone: '0244555888',
          vehicle_type: 'motor',
          license_plate: 'GR-8891-23',
          current_status: 'online',
          rating: 4.8,
          total_deliveries: 28,
          total_earnings: 490,
          current_lat: 5.6365,
          current_lng: -0.1645,
        }
      ]
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('GET /api/riders error:', err)
    return NextResponse.json({ error: err.message || 'Failed to list riders' }, { status: 500, headers: corsHeaders })
  }
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const body = await request.json()
    const parsed = riderSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.format() }, { status: 400, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      const { data, error } = await supabase
        .from('riders')
        .upsert({
          id: user.id,
          vehicle_type: parsed.data.vehicle_type,
          license_plate: parsed.data.license_plate,
          status: parsed.data.current_status,
          current_status: parsed.data.current_status,
          current_lat: parsed.data.current_lat || null,
          current_lng: parsed.data.current_lng || null,
          updated_at: new Date().toISOString(),
        })
        .select()
        .single()

      if (error) throw error
      return NextResponse.json({ success: true, rider: data }, { status: 200, headers: corsHeaders })
    }

    return NextResponse.json({
      success: true,
      rider: {
        id: user.id,
        ...parsed.data,
        updated_at: new Date().toISOString()
      }
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('POST /api/riders error:', err)
    return NextResponse.json({ error: err.message || 'Failed to save rider profile' }, { status: 500, headers: corsHeaders })
  }
}
