import { NextRequest, NextResponse } from 'next/server'
import { verifyUser, checkRateLimit } from '@/lib/auth'
import { getServerSupabase } from '@/lib/server-supabase'
import { z } from 'zod'

const customerSchema = z.object({
  full_name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().min(9, 'Valid phone required'),
  email: z.string().email().optional().or(z.literal('')),
})

function getCorsHeaders(origin: string | null) {
  return {
    'Access-Control-Allow-Origin': origin || '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  }
}

export async function OPTIONS(request: NextRequest) {
  return new NextResponse(null, { status: 200, headers: getCorsHeaders(request.headers.get('origin')) })
}

export async function GET(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)

  try {
    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      let query = supabase.from('customers').select('*, addresses(*)')
      if (user.role !== 'admin') {
        query = query.eq('user_id', user.id)
      }
      const { data, error } = await query.order('created_at', { ascending: false })
      if (error) throw error
      return NextResponse.json({ success: true, customers: data || [] }, { status: 200, headers: corsHeaders })
    }

    // Demo fallback
    return NextResponse.json({
      success: true,
      customers: [
        {
          id: user.id,
          user_id: user.id,
          full_name: user.phone || 'Ama Mensah',
          phone: user.phone || '0244123456',
          email: 'ama@example.com',
          created_at: new Date().toISOString(),
          addresses: [
            {
              id: 'addr_1',
              title: 'Home',
              address: 'East Legon, American House',
              city: 'Accra',
              region: 'Greater Accra',
              latitude: 5.6365,
              longitude: -0.1645,
              is_default: true,
            }
          ]
        }
      ]
    }, { status: 200, headers: corsHeaders })
  } catch (err: any) {
    console.error('GET /api/customers error:', err)
    return NextResponse.json({ error: err.message || 'Failed to fetch customers' }, { status: 500, headers: corsHeaders })
  }
}

export async function POST(request: NextRequest) {
  const origin = request.headers.get('origin')
  const corsHeaders = getCorsHeaders(origin)
  const ip = request.headers.get('x-forwarded-for') || 'unknown'

  try {
    const rateLimit = checkRateLimit(`customers:${ip}`, 15, 60000)
    if (!rateLimit.allowed) {
      return NextResponse.json({ error: 'Too many requests' }, { status: 429, headers: corsHeaders })
    }

    const user = await verifyUser(request)
    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401, headers: corsHeaders })
    }

    const body = await request.json()
    const parsed = customerSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.format() }, { status: 400, headers: corsHeaders })
    }

    const supabase = getServerSupabase()
    if (supabase) {
      const { data, error } = await supabase
        .from('customers')
        .upsert({
          user_id: user.id,
          full_name: parsed.data.full_name,
          phone: parsed.data.phone,
          email: parsed.data.email || null,
        }, { onConflict: 'user_id' })
        .select()
        .single()

      if (error) throw error
      return NextResponse.json({ success: true, customer: data }, { status: 201, headers: corsHeaders })
    }

    return NextResponse.json({
      success: true,
      customer: {
        id: `c_${Date.now()}`,
        user_id: user.id,
        ...parsed.data,
        created_at: new Date().toISOString()
      }
    }, { status: 201, headers: corsHeaders })
  } catch (err: any) {
    console.error('POST /api/customers error:', err)
    return NextResponse.json({ error: err.message || 'Failed to create customer' }, { status: 500, headers: corsHeaders })
  }
}
