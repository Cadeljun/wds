// WDS - Unified DB Layer - Switch between Supabase, Firestore, Demo via env
// NEXT_PUBLIC_DB_PROVIDER=firestore or supabase or demo

import type { Order, WDSUser, Rider, Customer, Address, Payment, OrderStatusHistory } from './supabase'

export type DbProvider = 'supabase' | 'firestore' | 'demo'

export function getDbProvider(): DbProvider {
  return (process.env.NEXT_PUBLIC_DB_PROVIDER as DbProvider) || 'supabase'
}

export function isSupabaseConfigured(): boolean {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
  return !!(url && key && !url.includes('placeholder') && !key.includes('placeholder') && !url.includes('xxx'))
}

export function isFirestoreConfigured(): boolean {
  const apiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY
  const projectId = process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID
  return !!(apiKey && projectId && !apiKey.includes('xxx') && !apiKey.includes('placeholder'))
}

// ----------------------------------------------------
// CUSTOMERS & ADDRESSES
// ----------------------------------------------------
export async function getCustomerProfileUnified(userId: string): Promise<{ data: Customer | null; error: any }> {
  if (isSupabaseConfigured()) {
    const { supabase } = await import('./supabase')
    const { data, error } = await supabase.from('customers').select('*').eq('user_id', userId).maybeSingle()
    return { data, error }
  }
  // Local fallback
  return {
    data: {
      id: userId,
      user_id: userId,
      full_name: 'Customer Account',
      phone: '0244123456',
      created_at: new Date().toISOString(),
    },
    error: null,
  }
}

export async function getAddressesUnified(userId: string): Promise<{ data: Address[]; error: any }> {
  if (isSupabaseConfigured()) {
    const { supabase } = await import('./supabase')
    const { data, error } = await supabase.from('addresses').select('*').eq('user_id', userId).order('is_default', { ascending: false })
    return { data: data || [], error }
  }
  return {
    data: [
      {
        id: 'addr_1',
        user_id: userId,
        title: 'Home',
        address: 'East Legon, American House',
        city: 'Accra',
        region: 'Greater Accra',
        latitude: 5.6365,
        longitude: -0.1645,
        is_default: true,
        created_at: new Date().toISOString(),
      },
      {
        id: 'addr_2',
        user_id: userId,
        title: 'Office',
        address: 'Osu, Oxford Street',
        city: 'Accra',
        region: 'Greater Accra',
        latitude: 5.5560,
        longitude: -0.1760,
        is_default: false,
        created_at: new Date().toISOString(),
      }
    ],
    error: null,
  }
}

// ----------------------------------------------------
// ORDERS
// ----------------------------------------------------
export async function createOrderUnified(orderData: any): Promise<{ data: any; error: any }> {
  const provider = getDbProvider()

  if (provider === 'firestore' && isFirestoreConfigured()) {
    const { createOrder } = await import('./firestore')
    return createOrder(orderData)
  } else if (isSupabaseConfigured()) {
    const { supabase } = await import('./supabase')
    const payload = {
      ...orderData,
      delivery_address: orderData.delivery_address || orderData.dropoff_address,
      package_description: orderData.package_description || orderData.description,
      delivery_fee: orderData.delivery_fee || orderData.price,
      order_status: orderData.order_status || orderData.status || 'pending',
    }
    const { data, error } = await supabase.from('orders').insert(payload).select().single()
    return { data, error }
  } else {
    // Demo localStorage fallback
    const orders = JSON.parse(localStorage.getItem('wds_orders_v2') || '[]')
    const newOrder = {
      id: 'WDS-' + Date.now().toString().slice(-6),
      order_code: 'WDS-' + Math.random().toString(36).substring(2, 8).toUpperCase(),
      ...orderData,
      created_at: new Date().toISOString(),
    }
    orders.unshift(newOrder)
    localStorage.setItem('wds_orders_v2', JSON.stringify(orders))
    return { data: newOrder, error: null }
  }
}

export async function getOrdersUnified(customerId?: string): Promise<{ data: any[]; error: any }> {
  const provider = getDbProvider()

  if (provider === 'firestore' && isFirestoreConfigured() && customerId) {
    const { getOrdersByCustomer } = await import('./firestore')
    return getOrdersByCustomer(customerId)
  } else if (isSupabaseConfigured()) {
    const { supabase } = await import('./supabase')
    let query = supabase.from('orders').select('*')
    if (customerId) {
      query = query.eq('customer_id', customerId)
    }
    const { data, error } = await query.order('created_at', { ascending: false }).limit(50)
    return { data: data || [], error }
  } else {
    const orders = JSON.parse(localStorage.getItem('wds_orders_v2') || '[]')
    const filtered = customerId
      ? orders.filter((o: any) => o.customerId === customerId || o.customer_id === customerId)
      : orders
    return { data: filtered, error: null }
  }
}

export function subscribeToOrdersUnified(customerId: string, callback: (orders: any[]) => void): () => void {
  const provider = getDbProvider()

  if (provider === 'firestore' && isFirestoreConfigured()) {
    let unsubscribe: any = () => {}
    import('./firestore').then(({ subscribeToOrders }) => {
      unsubscribe = subscribeToOrders(customerId, callback)
    })
    return () => { if (typeof unsubscribe === 'function') unsubscribe() }
  } else if (isSupabaseConfigured()) {
    let channelRef: any = null
    import('./supabase').then(({ supabase }) => {
      // Subscribe to all changes for this customer's orders
      channelRef = supabase
        .channel(`orders_customer_${customerId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'orders', filter: `customer_id=eq.${customerId}` },
          () => {
            getOrdersUnified(customerId).then(({ data }) => callback(data))
          }
        )
        .subscribe()
    })
    return () => {
      if (channelRef) {
        import('./supabase').then(({ supabase }) => supabase.removeChannel(channelRef))
      }
    }
  } else {
    // Demo - fetch once and return noop
    getOrdersUnified(customerId).then(({ data }) => callback(data))
    return () => {}
  }
}

export function subscribeToRiderOrdersUnified(riderId: string, callback: (orders: any[]) => void): () => void {
  if (isSupabaseConfigured()) {
    let channelRef: any = null
    import('./supabase').then(({ supabase }) => {
      channelRef = supabase
        .channel(`orders_rider_${riderId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'orders' },
          () => {
            // Refetch orders relevant to rider
            supabase
              .from('orders')
              .select('*')
              .or(`assigned_rider_id.eq.${riderId},rider_id.eq.${riderId},status.eq.pending,order_status.eq.pending`)
              .order('created_at', { ascending: false })
              .then(({ data }) => callback(data || []))
          }
        )
        .subscribe()
    })
    return () => {
      if (channelRef) {
        import('./supabase').then(({ supabase }) => supabase.removeChannel(channelRef))
      }
    }
  }
  return () => {}
}

// ----------------------------------------------------
// STATUS & AUDIT HISTORY
// ----------------------------------------------------
export async function getOrderStatusHistoryUnified(orderId: string): Promise<{ data: OrderStatusHistory[]; error: any }> {
  if (isSupabaseConfigured()) {
    const { supabase } = await import('./supabase')
    const { data, error } = await supabase
      .from('order_status_history')
      .select('*')
      .eq('order_id', orderId)
      .order('created_at', { ascending: true })
    return { data: data || [], error }
  }
  return { data: [], error: null }
}

export async function getCurrentUserUnified(): Promise<WDSUser | null> {
  const provider = getDbProvider()

  if (provider === 'firestore' && isFirestoreConfigured()) {
    const { getCurrentUser } = await import('./firestore')
    return getCurrentUser()
  } else if (isSupabaseConfigured()) {
    const { getCurrentUser } = await import('./supabase')
    return getCurrentUser()
  } else {
    const session = typeof window !== 'undefined' ? localStorage.getItem('wds_session_v2') : null
    return session ? JSON.parse(session) : null
  }
}

export function getProviderInfo() {
  const provider = getDbProvider()
  const supabaseConfigured = isSupabaseConfigured()
  const firestoreConfigured = isFirestoreConfigured()

  return {
    provider,
    supabaseConfigured,
    firestoreConfigured,
    activeProvider: provider === 'firestore' && firestoreConfigured ? 'firestore' : supabaseConfigured ? 'supabase' : 'demo',
    message: provider === 'firestore' && firestoreConfigured ? 'Using Firestore' : supabaseConfigured ? 'Using Supabase (Persistent)' : 'Using Demo localStorage (no backend)',
  }
}
