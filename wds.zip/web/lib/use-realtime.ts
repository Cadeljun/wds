'use client'

import { useEffect, useState, useRef, useCallback } from 'react'
import { LiveOrder, LiveRiderLocation } from '@/lib/realtime-service'

export interface RealtimeState {
  orders: LiveOrder[]
  riders: LiveRiderLocation[]
  isConnected: boolean
  lastEventAt: string | null
  error: string | null
}

export function useRealtimeData(userRole?: string, userId?: string) {
  const [orders, setOrders] = useState<LiveOrder[]>([])
  const [riders, setRiders] = useState<LiveRiderLocation[]>([])
  const [isConnected, setIsConnected] = useState<boolean>(false)
  const [lastEventAt, setLastEventAt] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const eventSourceRef = useRef<EventSource | null>(null)
  const retryTimeoutRef = useRef<NodeJS.Timeout | null>(null)

  const connect = useCallback(() => {
    if (typeof window === 'undefined') return

    // Clean up existing if open
    if (eventSourceRef.current) {
      eventSourceRef.current.close()
    }

    try {
      const es = new EventSource('/api/realtime/stream')
      eventSourceRef.current = es

      es.onopen = () => {
        setIsConnected(true)
        setError(null)
      }

      // Initial state snapshot
      es.addEventListener('init', (e: MessageEvent) => {
        try {
          const data = JSON.parse(e.data)
          if (data.orders) setOrders(data.orders)
          if (data.riders) setRiders(data.riders)
          setLastEventAt(new Date().toLocaleTimeString())
          setIsConnected(true)
        } catch (err) {
          console.error('Failed to parse init realtime payload:', err)
        }
      })

      // Order created event
      es.addEventListener('order:created', (e: MessageEvent) => {
        try {
          const newOrder: LiveOrder = JSON.parse(e.data)
          setOrders(prev => {
            // Idempotent insertion
            if (prev.some(o => o.id === newOrder.id)) return prev
            return [newOrder, ...prev]
          })
          setLastEventAt(new Date().toLocaleTimeString())
        } catch (err) {
          console.error('Failed to parse order:created event:', err)
        }
      })

      // Order updated event
      es.addEventListener('order:updated', (e: MessageEvent) => {
        try {
          const updatedOrder: LiveOrder = JSON.parse(e.data)
          setOrders(prev => {
            const index = prev.findIndex(o => o.id === updatedOrder.id)
            if (index === -1) return [updatedOrder, ...prev]
            const copy = [...prev]
            copy[index] = { ...copy[index], ...updatedOrder }
            return copy
          })
          setLastEventAt(new Date().toLocaleTimeString())
        } catch (err) {
          console.error('Failed to parse order:updated event:', err)
        }
      })

      // Rider location event
      es.addEventListener('rider:location', (e: MessageEvent) => {
        try {
          const loc: LiveRiderLocation = JSON.parse(e.data)
          setRiders(prev => {
            const index = prev.findIndex(r => r.riderId === loc.riderId)
            if (index === -1) return [...prev, loc]
            const copy = [...prev]
            copy[index] = loc
            return copy
          })
          setLastEventAt(new Date().toLocaleTimeString())
        } catch (err) {
          console.error('Failed to parse rider:location event:', err)
        }
      })

      es.onerror = () => {
        setIsConnected(false)
        setError('Real-time connection interrupted. Auto-reconnecting...')
        es.close()

        // Auto-reconnect with backoff
        if (!retryTimeoutRef.current) {
          retryTimeoutRef.current = setTimeout(() => {
            retryTimeoutRef.current = null
            connect()
          }, 3000)
        }
      }
    } catch (err: any) {
      setIsConnected(false)
      setError(err?.message || 'Failed to initialize real-time connection')
    }
  }, [])

  useEffect(() => {
    connect()

    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close()
      }
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }
    }
  }, [connect])

  // Filter orders by role/user if provided
  const filteredOrders = orders.filter(o => {
    if (!userRole || userRole === 'admin') return true
    if (userRole === 'rider') return o.riderId === userId || o.status === 'pending'
    return o.customerId === userId
  })

  return {
    orders: filteredOrders,
    allOrders: orders,
    riders,
    isConnected,
    lastEventAt,
    error,
    refresh: connect,
  }
}
