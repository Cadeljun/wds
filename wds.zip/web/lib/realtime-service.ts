// Server-authoritative in-memory real-time event broadcaster and store
// Used by Next.js API routes for Server-Sent Events (SSE) and real-time syncing across clients

export interface RealtimeEvent {
  id: string
  type: 'order:created' | 'order:updated' | 'order:status' | 'rider:location' | 'rider:status'
  timestamp: string
  payload: any
}

export interface LiveRiderLocation {
  riderId: string
  riderName: string
  lat: number
  lng: number
  heading?: number
  speed?: number
  updatedAt: string
}

export interface LiveOrder {
  id: string
  orderCode: string
  customerId: string
  customerName?: string
  riderId?: string
  riderName?: string
  pickup: string
  pickupCoords?: { lat: number; lng: number }
  dropoff: string
  dropoffCoords?: { lat: number; lng: number }
  type: string
  description?: string
  recipientName?: string
  recipientPhone?: string
  price: string
  paymentMethod: string
  status: 'pending' | 'accepted' | 'picked_up' | 'on_the_way' | 'delivered' | 'cancelled'
  createdAt: string
  updatedAt: string
  etaMinutes?: number
  distanceKm?: number
}

// Global in-memory cache for the Node.js process (lives across requests)
declare global {
  // eslint-disable-next-line no-var
  var __wds_live_orders: Map<string, LiveOrder> | undefined
  // eslint-disable-next-line no-var
  var __wds_live_riders: Map<string, LiveRiderLocation> | undefined
  // eslint-disable-next-line no-var
  var __wds_subscribers: Set<(event: RealtimeEvent) => void> | undefined
}

function getOrdersMap(): Map<string, LiveOrder> {
  if (!global.__wds_live_orders) {
    global.__wds_live_orders = new Map<string, LiveOrder>()
    // Seed initial orders so real-time clients have immediate data
    const initialOrders: LiveOrder[] = [
      {
        id: 'WDS-91',
        orderCode: 'WDS-91',
        customerId: 'u_0244123456',
        customerName: 'Ama Mensah',
        riderId: 'u_0244987654',
        riderName: 'Kwame Asare',
        pickup: 'Madina Market',
        pickupCoords: { lat: 5.6698, lng: -0.1654 },
        dropoff: 'Legon Campus, Commonwealth',
        dropoffCoords: { lat: 5.6506, lng: -0.1870 },
        type: 'Food',
        price: 'GHS 35',
        paymentMethod: 'momo_mtn',
        status: 'delivered',
        createdAt: new Date(Date.now() - 3600000).toISOString(),
        updatedAt: new Date(Date.now() - 1800000).toISOString(),
        distanceKm: 4.2,
      },
      {
        id: 'WDS-90',
        orderCode: 'WDS-90',
        customerId: 'u_0244123456',
        customerName: 'Ama Mensah',
        riderId: 'u_0244987654',
        riderName: 'Kwame Asare',
        pickup: 'Kaneshie Market',
        pickupCoords: { lat: 5.5684, lng: -0.2372 },
        dropoff: 'Dansoman, Roundabout',
        dropoffCoords: { lat: 5.5492, lng: -0.2608 },
        type: 'Grocery',
        price: 'GHS 52',
        paymentMethod: 'momo_vodafone',
        status: 'on_the_way',
        createdAt: new Date(Date.now() - 1200000).toISOString(),
        updatedAt: new Date().toISOString(),
        distanceKm: 6.8,
        etaMinutes: 12,
      },
      {
        id: 'WDS-94',
        orderCode: 'WDS-94',
        customerId: 'u_demo_customer',
        customerName: 'Kofi Boateng',
        pickup: 'Osu, Oxford Street',
        pickupCoords: { lat: 5.5560, lng: -0.1760 },
        dropoff: 'Airport Residential',
        dropoffCoords: { lat: 5.6037, lng: -0.1870 },
        type: 'Document',
        price: 'GHS 28',
        paymentMethod: 'momo_mtn',
        status: 'pending',
        createdAt: new Date(Date.now() - 300000).toISOString(),
        updatedAt: new Date(Date.now() - 300000).toISOString(),
        distanceKm: 5.1,
      },
    ]

    for (const order of initialOrders) {
      global.__wds_live_orders.set(order.id, order)
    }
  }
  return global.__wds_live_orders
}

function getRidersMap(): Map<string, LiveRiderLocation> {
  if (!global.__wds_live_riders) {
    global.__wds_live_riders = new Map<string, LiveRiderLocation>()
    // Seed initial rider locations across Accra
    const initialRiders: LiveRiderLocation[] = [
      {
        riderId: 'u_0244987654',
        riderName: 'Kwame Asare',
        lat: 5.5780,
        lng: -0.2450,
        heading: 45,
        speed: 32,
        updatedAt: new Date().toISOString(),
      },
      {
        riderId: 'u_rider_2',
        riderName: 'Kofi Mensah',
        lat: 5.6365,
        lng: -0.1645,
        heading: 120,
        speed: 28,
        updatedAt: new Date().toISOString(),
      },
      {
        riderId: 'u_rider_3',
        riderName: 'Emmanuel Osei',
        lat: 5.5560,
        lng: -0.1760,
        heading: 270,
        speed: 0,
        updatedAt: new Date().toISOString(),
      },
    ]

    for (const rider of initialRiders) {
      global.__wds_live_riders.set(rider.riderId, rider)
    }
  }
  return global.__wds_live_riders
}

function getSubscribers(): Set<(event: RealtimeEvent) => void> {
  if (!global.__wds_subscribers) {
    global.__wds_subscribers = new Set()
  }
  return global.__wds_subscribers
}

// Broadcaster to all connected clients
export function broadcastEvent(event: RealtimeEvent) {
  const subscribers = getSubscribers()
  subscribers.forEach(listener => {
    try {
      listener(event)
    } catch (err) {
      console.error('Error broadcasting event to listener:', err)
    }
  })
}

export function subscribeToEvents(callback: (event: RealtimeEvent) => void): () => void {
  const subscribers = getSubscribers()
  subscribers.add(callback)
  return () => {
    subscribers.delete(callback)
  }
}

// Accessors for Orders
export function getLiveOrders(): LiveOrder[] {
  return Array.from(getOrdersMap().values()).sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  )
}

export function getLiveOrder(id: string): LiveOrder | null {
  return getOrdersMap().get(id) || null
}

export function upsertLiveOrder(order: Partial<LiveOrder> & { id: string }): LiveOrder {
  const map = getOrdersMap()
  const existing = map.get(order.id)
  const now = new Date().toISOString()

  const updated: LiveOrder = {
    id: order.id,
    orderCode: order.orderCode || existing?.orderCode || order.id,
    customerId: order.customerId || existing?.customerId || 'unknown',
    customerName: order.customerName || existing?.customerName,
    riderId: order.riderId !== undefined ? order.riderId : existing?.riderId,
    riderName: order.riderName !== undefined ? order.riderName : existing?.riderName,
    pickup: order.pickup || existing?.pickup || '',
    pickupCoords: order.pickupCoords || existing?.pickupCoords,
    dropoff: order.dropoff || existing?.dropoff || '',
    dropoffCoords: order.dropoffCoords || existing?.dropoffCoords,
    type: order.type || existing?.type || 'parcel',
    description: order.description !== undefined ? order.description : existing?.description,
    recipientName: order.recipientName !== undefined ? order.recipientName : existing?.recipientName,
    recipientPhone: order.recipientPhone !== undefined ? order.recipientPhone : existing?.recipientPhone,
    price: order.price || existing?.price || 'GHS 35',
    paymentMethod: order.paymentMethod || existing?.paymentMethod || 'momo_mtn',
    status: order.status || existing?.status || 'pending',
    createdAt: existing?.createdAt || order.createdAt || now,
    updatedAt: now,
    etaMinutes: order.etaMinutes !== undefined ? order.etaMinutes : existing?.etaMinutes,
    distanceKm: order.distanceKm !== undefined ? order.distanceKm : existing?.distanceKm,
  }

  map.set(order.id, updated)

  broadcastEvent({
    id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    type: existing ? 'order:updated' : 'order:created',
    timestamp: now,
    payload: updated,
  })

  return updated
}

// Accessors for Riders
export function getLiveRiders(): LiveRiderLocation[] {
  return Array.from(getRidersMap().values())
}

export function updateRiderLocation(location: LiveRiderLocation): LiveRiderLocation {
  const map = getRidersMap()
  map.set(location.riderId, location)

  broadcastEvent({
    id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    type: 'rider:location',
    timestamp: location.updatedAt,
    payload: location,
  })

  return location
}
